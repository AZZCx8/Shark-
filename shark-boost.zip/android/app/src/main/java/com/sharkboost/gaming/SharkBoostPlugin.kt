package com.sharkboost.gaming

import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.io.ByteArrayOutputStream

@CapacitorPlugin(name = "SharkBoost")
class SharkBoostPlugin : Plugin() {

    @PluginMethod
    fun getInstalledGames(call: PluginCall) {
        val pm = context.packageManager
        val launchIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(launchIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launchIntent, 0)
        }

        val gamesArray = JSArray()
        val seen = HashSet<String>()

        for (resolveInfo in apps) {
            val appInfo = resolveInfo.activityInfo?.applicationInfo ?: continue
            val pkg = appInfo.packageName ?: continue
            if (pkg == context.packageName || !seen.add(pkg)) continue

            val isGameCategory = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appInfo.category == ApplicationInfo.CATEGORY_GAME
            } else {
                @Suppress("DEPRECATION")
                (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            }

            if (isGameCategory) {
                val item = JSObject().apply {
                    put("packageName", pkg)
                    put("name", resolveInfo.loadLabel(pm).toString())
                    put("iconBase64", drawableToBase64(resolveInfo.loadIcon(pm)))
                    put("isGame", true)
                }
                gamesArray.put(item)
            }
        }

        val result = JSObject().apply {
            put("games", gamesArray)
            put("count", gamesArray.length())
        }
        call.resolve(result)
    }

    @PluginMethod
    fun launchGame(call: PluginCall) {
        val packageName = call.getString("packageName")
        if (packageName.isNullOrBlank()) {
            call.reject("Missing packageName")
            return
        }
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent == null) {
            call.reject("Game package is not installed on this device")
            return
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        call.resolve(JSObject().put("launched", true).put("packageName", packageName))
    }

    @PluginMethod
    fun getDeviceTelemetry(call: PluginCall) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val result = JSObject().apply {
            put("availMemMb", memInfo.availMem / (1024 * 1024))
            put("totalMemMb", memInfo.totalMem / (1024 * 1024))
            put("lowMemory", memInfo.lowMemory)
            put("powerSaveMode", pm.isPowerSaveMode)
            put("batteryPercent", if (level >= 0 && scale > 0) (level * 100) / scale else -1)
            put("batteryCharging", isCharging)
            put("batteryTempC", if (tempTenths > 0) tempTenths / 10.0 else -1.0)
            put("dndAccessGranted", nm.isNotificationPolicyAccessGranted)
            put("dndActive", nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put("thermalStatus", pm.currentThermalStatus)
            }
        }
        call.resolve(result)
    }

    @PluginMethod
    fun setGamingDnd(call: PluginCall) {
        val enable = call.getBoolean("enable", true) ?: true
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            call.resolve(JSObject().put("permissionRequired", true).put("active", false))
            return
        }
        val filter = if (enable) {
            NotificationManager.INTERRUPTION_FILTER_PRIORITY
        } else {
            NotificationManager.INTERRUPTION_FILTER_ALL
        }
        nm.setInterruptionFilter(filter)
        call.resolve(JSObject().put("permissionRequired", false).put("active", enable))
    }

    @PluginMethod
    fun openSystemSettings(call: PluginCall) {
        val target = call.getString("target") ?: "app"
        val packageName = call.getString("packageName")
        val intent = when (target) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "battery_optimization" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            "dnd" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            "developer" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            "network" -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            "app_details" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${packageName ?: context.packageName}")
            }
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        call.resolve(JSObject().put("opened", target))
    }

    private fun drawableToBase64(drawable: Drawable): String {
        val bitmap = if (drawable is BitmapDrawable && drawable.bitmap != null) {
            drawable.bitmap
        } else {
            val w = drawable.intrinsicWidth.coerceIn(48, 128)
            val h = drawable.intrinsicHeight.coerceIn(48, 128)
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bmp ->
                val canvas = Canvas(bmp)
                drawable.setBounds(0, 0, canvas.width, canvas.height)
                drawable.draw(canvas)
            }
        }
        val scaled = Bitmap.createScaledBitmap(bitmap, 96, 96, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 90, out)
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}

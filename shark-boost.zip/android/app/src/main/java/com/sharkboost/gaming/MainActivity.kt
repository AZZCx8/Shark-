package com.sharkboost.gaming

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(SharkBoostPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}

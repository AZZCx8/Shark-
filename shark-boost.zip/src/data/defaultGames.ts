import type { GameItem, GameProfile } from '../types/shark';

export const DEFAULT_PROFILE: GameProfile = {
  keepScreenAwake: true,
  measureFrameCadence: true,
  enableBreakTimer: false,
  breakMinutes: 45,
  checkNetworkBeforeLaunch: true,
};

export const GAME_ICON_PRESETS = [
  {
    id: 'shooter',
    labelAr: 'تصويب تكتيكي',
    labelEn: 'Tactical Shooter',
    url: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
  {
    id: 'racing',
    labelAr: 'سباقات سريعة',
    labelEn: 'Arcade Racing',
    url: '/src/assets/images/game_cyber_racing_1794668573421.jpg',
  },
  {
    id: 'rpg',
    labelAr: 'تقمص أدوار',
    labelEn: 'Action RPG',
    url: '/src/assets/images/game_fantasy_rpg_1794668574148.jpg',
  },
  {
    id: 'moba',
    labelAr: 'ساحة تنافسية',
    labelEn: 'Arena MOBA',
    url: '/src/assets/images/game_arena_moba_1794668574886.jpg',
  },
];

export const POPULAR_ANDROID_CATALOG: Array<{
  name: string;
  packageName: string;
  category: GameItem['category'];
  iconUrl: string;
}> = [
  {
    name: 'PUBG MOBILE',
    packageName: 'com.tencent.ig',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
  {
    name: 'Call of Duty: Mobile',
    packageName: 'com.activision.callofduty.shooter',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
  {
    name: 'Asphalt Legends Unite',
    packageName: 'com.gameloft.android.ANMP.GloftA9HM',
    category: 'racing',
    iconUrl: '/src/assets/images/game_cyber_racing_1794668573421.jpg',
  },
  {
    name: 'Genshin Impact',
    packageName: 'com.miHoYo.GenshinImpact',
    category: 'rpg',
    iconUrl: '/src/assets/images/game_fantasy_rpg_1794668574148.jpg',
  },
  {
    name: 'Mobile Legends: Bang Bang',
    packageName: 'com.mobile.legends',
    category: 'moba',
    iconUrl: '/src/assets/images/game_arena_moba_1794668574886.jpg',
  },
  {
    name: 'Free Fire',
    packageName: 'com.dts.freefireth',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
  {
    name: 'Brawl Stars',
    packageName: 'com.supercell.brawlstars',
    category: 'moba',
    iconUrl: '/src/assets/images/game_arena_moba_1794668574886.jpg',
  },
  {
    name: 'Blood Strike',
    packageName: 'com.netease.newspike',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
  {
    name: 'Standoff 2',
    packageName: 'com.axlebolt.standoff2',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
  },
];

export const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'pubg-mobile',
    name: 'PUBG MOBILE',
    packageName: 'com.tencent.ig',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
    isPinned: true,
    profile: { ...DEFAULT_PROFILE },
  },
  {
    id: 'cod-mobile',
    name: 'Call of Duty: Mobile',
    packageName: 'com.activision.callofduty.shooter',
    category: 'shooter',
    iconUrl: '/src/assets/images/game_tactical_shooter_1794668573584.jpg',
    isPinned: true,
    profile: { ...DEFAULT_PROFILE },
  },
  {
    id: 'asphalt-legends',
    name: 'Asphalt Legends Unite',
    packageName: 'com.gameloft.android.ANMP.GloftA9HM',
    category: 'racing',
    iconUrl: '/src/assets/images/game_cyber_racing_1794668573421.jpg',
    isPinned: false,
    profile: { ...DEFAULT_PROFILE, checkNetworkBeforeLaunch: false },
  },
  {
    id: 'genshin-impact',
    name: 'Genshin Impact',
    packageName: 'com.miHoYo.GenshinImpact',
    category: 'rpg',
    iconUrl: '/src/assets/images/game_fantasy_rpg_1794668574148.jpg',
    isPinned: false,
    profile: { ...DEFAULT_PROFILE, enableBreakTimer: true, breakMinutes: 45 },
  },
  {
    id: 'mobile-legends',
    name: 'Mobile Legends: Bang Bang',
    packageName: 'com.mobile.legends',
    category: 'moba',
    iconUrl: '/src/assets/images/game_arena_moba_1794668574886.jpg',
    isPinned: true,
    profile: { ...DEFAULT_PROFILE },
  },
];

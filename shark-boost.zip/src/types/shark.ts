export type Language = 'ar' | 'en';
export type ThemeMode = 'dark' | 'light';
export type AppTab = 'booster' | 'gaming' | 'network' | 'performance' | 'settings';
export type GameCategory = 'shooter' | 'racing' | 'rpg' | 'moba' | 'sandbox' | 'other';

export interface GameProfile {
  keepScreenAwake: boolean;
  measureFrameCadence: boolean;
  enableBreakTimer: boolean;
  breakMinutes: number;
  checkNetworkBeforeLaunch: boolean;
}

export interface GameItem {
  id: string;
  name: string;
  packageName: string;
  category: GameCategory;
  iconUrl: string;
  launchUrl?: string;
  isPinned: boolean;
  isNativeDetected?: boolean;
  lastLaunchedAt?: number;
  profile: GameProfile;
}

export interface NetworkSample {
  seq: number;
  rttMs: number | null;
  jitterMs: number | null;
  status: 'ok' | 'timeout' | 'error';
  timestamp: number;
}

export interface NetworkStats {
  sent: number;
  received: number;
  lost: number;
  lossPercent: number;
  minMs: number | null;
  avgMs: number | null;
  maxMs: number | null;
  jitterMs: number | null;
}

export interface DeviceTelemetry {
  platform: 'android-native' | 'web';
  cpuCores: number | null;
  deviceMemoryGb: number | null;
  nativeAvailMemMb: number | null;
  nativeTotalMemMb: number | null;
  storageUsedMb: number | null;
  storageQuotaMb: number | null;
  batteryPercent: number | null;
  batteryCharging: boolean | null;
  batteryTempC: number | null;
  powerSaveMode: boolean | null;
  dndAccessGranted: boolean | null;
  dndActive: boolean | null;
  connectionType: string | null;
  connectionDownlinkMbps: number | null;
  connectionRttMs: number | null;
  connectionSaveData: boolean | null;
}

export interface FrameCadenceResult {
  hz: number;
  avgFrameMs: number;
  p95FrameMs: number;
  droppedFrames: number;
  sampleFrames: number;
}

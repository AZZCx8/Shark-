import { Capacitor, registerPlugin } from '@capacitor/core';
import type { DeviceTelemetry, FrameCadenceResult, GameItem } from '../types/shark';
import { DEFAULT_PROFILE } from '../data/defaultGames';

interface NativeGameInfo {
  packageName: string;
  name: string;
  iconBase64: string;
  isGame: boolean;
}

interface NativeTelemetry {
  availMemMb: number;
  totalMemMb: number;
  lowMemory: boolean;
  powerSaveMode: boolean;
  batteryPercent: number;
  batteryCharging: boolean;
  batteryTempC: number;
  dndAccessGranted: boolean;
  dndActive: boolean;
}

interface SharkBoostNativePlugin {
  getInstalledGames(): Promise<{ games: NativeGameInfo[]; count: number }>;
  launchGame(options: { packageName: string }): Promise<{ launched: boolean; packageName: string }>;
  getDeviceTelemetry(): Promise<NativeTelemetry>;
  setGamingDnd(options: { enable: boolean }): Promise<{ permissionRequired: boolean; active: boolean }>;
  openSystemSettings(options: { target: string; packageName?: string }): Promise<{ opened: string }>;
}

const SharkBoostNative = registerPlugin<SharkBoostNativePlugin>('SharkBoost');

export function isNativeAndroid(): boolean {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
}

export function isAndroidBrowser(): boolean {
  return typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent);
}

export async function scanInstalledAndroidGames(): Promise<{
  source: 'native' | 'web';
  games: GameItem[];
}> {
  if (isNativeAndroid()) {
    try {
      const res = await SharkBoostNative.getInstalledGames();
      const mapped: GameItem[] = res.games.map((g) => ({
        id: g.packageName,
        name: g.name,
        packageName: g.packageName,
        category: 'other',
        iconUrl: g.iconBase64,
        isPinned: false,
        isNativeDetected: true,
        profile: { ...DEFAULT_PROFILE },
      }));
      return { source: 'native', games: mapped };
    } catch {
      return { source: 'web', games: [] };
    }
  }
  return { source: 'web', games: [] };
}

export async function launchNativeOrIntentGame(game: GameItem): Promise<{
  mode: 'native' | 'url' | 'intent' | 'session-only';
  launched: boolean;
}> {
  if (isNativeAndroid() && game.packageName) {
    try {
      const res = await SharkBoostNative.launchGame({ packageName: game.packageName });
      if (res.launched) {
        return { mode: 'native', launched: true };
      }
    } catch {
      // Fall through to URL/session HUD
    }
  }

  if (game.launchUrl && /^https?:\/\//i.test(game.launchUrl)) {
    return { mode: 'url', launched: true };
  }

  if (isAndroidBrowser() && game.packageName) {
    return { mode: 'intent', launched: true };
  }

  return { mode: 'session-only', launched: false };
}

export function buildAndroidLaunchIntentUri(packageName: string): string {
  const safePkg = packageName.replace(/[^a-zA-Z0-9._]/g, '');
  return `intent://#Intent;package=${safePkg};action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;end`;
}

export async function openAndroidSetting(
  target:
    | 'wifi'
    | 'display'
    | 'battery'
    | 'battery_optimization'
    | 'dnd'
    | 'developer'
    | 'network'
    | 'app_details',
  packageName?: string
): Promise<{ mode: 'native' | 'intent' | 'info'; intentUri?: string }> {
  if (isNativeAndroid()) {
    await SharkBoostNative.openSystemSettings({ target, packageName });
    return { mode: 'native' };
  }

  const actionMap: Record<string, string> = {
    wifi: 'android.settings.WIFI_SETTINGS',
    display: 'android.settings.DISPLAY_SETTINGS',
    battery: 'android.settings.BATTERY_SAVER_SETTINGS',
    battery_optimization: 'android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS',
    dnd: 'android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS',
    developer: 'android.settings.APPLICATION_DEVELOPMENT_SETTINGS',
    network: 'android.settings.WIRELESS_SETTINGS',
    app_details: 'android.settings.APPLICATION_SETTINGS',
  };

  const intentUri = `intent:#Intent;action=${actionMap[target] || 'android.settings.SETTINGS'};end`;
  if (isAndroidBrowser()) {
    return { mode: 'intent', intentUri };
  }
  return { mode: 'info', intentUri };
}

export async function toggleNativeDnd(enable: boolean): Promise<{
  supported: boolean;
  permissionRequired?: boolean;
  active?: boolean;
}> {
  if (!isNativeAndroid()) {
    return { supported: false };
  }
  const res = await SharkBoostNative.setGamingDnd({ enable });
  return { supported: true, ...res };
}

export async function collectDeviceTelemetry(): Promise<DeviceTelemetry> {
  const nav = navigator as Navigator & {
    deviceMemory?: number;
    getBattery?: () => Promise<{
      level: number;
      charging: boolean;
      addEventListener: (type: string, fn: () => void) => void;
    }>;
    connection?: {
      effectiveType?: string;
      downlink?: number;
      rtt?: number;
      saveData?: boolean;
    };
  };

  let storageUsedMb: number | null = null;
  let storageQuotaMb: number | null = null;
  if (navigator.storage?.estimate) {
    try {
      const est = await navigator.storage.estimate();
      if (typeof est.usage === 'number') storageUsedMb = Math.round(est.usage / (1024 * 1024));
      if (typeof est.quota === 'number') storageQuotaMb = Math.round(est.quota / (1024 * 1024));
    } catch {
      // Ignore storage estimate failure
    }
  }

  let batteryPercent: number | null = null;
  let batteryCharging: boolean | null = null;
  if (typeof nav.getBattery === 'function') {
    try {
      const bat = await nav.getBattery();
      batteryPercent = Math.round(bat.level * 100);
      batteryCharging = bat.charging;
    } catch {
      // Ignore battery API errors
    }
  }

  const base: DeviceTelemetry = {
    platform: isNativeAndroid() ? 'android-native' : 'web',
    cpuCores: typeof navigator.hardwareConcurrency === 'number' ? navigator.hardwareConcurrency : null,
    deviceMemoryGb: typeof nav.deviceMemory === 'number' ? nav.deviceMemory : null,
    nativeAvailMemMb: null,
    nativeTotalMemMb: null,
    storageUsedMb,
    storageQuotaMb,
    batteryPercent,
    batteryCharging,
    batteryTempC: null,
    powerSaveMode: null,
    dndAccessGranted: null,
    dndActive: null,
    connectionType: nav.connection?.effectiveType ?? null,
    connectionDownlinkMbps: typeof nav.connection?.downlink === 'number' ? nav.connection.downlink : null,
    connectionRttMs: typeof nav.connection?.rtt === 'number' ? nav.connection.rtt : null,
    connectionSaveData: typeof nav.connection?.saveData === 'boolean' ? nav.connection.saveData : null,
  };

  if (isNativeAndroid()) {
    try {
      const nativeTel = await SharkBoostNative.getDeviceTelemetry();
      return {
        ...base,
        nativeAvailMemMb: nativeTel.availMemMb,
        nativeTotalMemMb: nativeTel.totalMemMb,
        batteryPercent: nativeTel.batteryPercent >= 0 ? nativeTel.batteryPercent : base.batteryPercent,
        batteryCharging: nativeTel.batteryCharging,
        batteryTempC: nativeTel.batteryTempC > 0 ? nativeTel.batteryTempC : null,
        powerSaveMode: nativeTel.powerSaveMode,
        dndAccessGranted: nativeTel.dndAccessGranted,
        dndActive: nativeTel.dndActive,
      };
    } catch {
      return base;
    }
  }

  return base;
}

export function measureDisplayCadence(sampleFrames = 120): Promise<FrameCadenceResult> {
  return new Promise((resolve) => {
    const deltas: number[] = [];
    let lastTime: number | null = null;
    let count = 0;

    function step(now: number) {
      if (lastTime !== null) {
        const dt = now - lastTime;
        if (dt > 0 && dt < 200) {
          deltas.push(dt);
        }
      }
      lastTime = now;
      count += 1;

      if (count <= sampleFrames) {
        requestAnimationFrame(step);
      } else {
        if (deltas.length === 0) {
          resolve({ hz: 60, avgFrameMs: 16.67, p95FrameMs: 16.67, droppedFrames: 0, sampleFrames: 0 });
          return;
        }
        const sum = deltas.reduce((acc, v) => acc + v, 0);
        const avg = sum / deltas.length;
        const sorted = [...deltas].sort((a, b) => a - b);
        const p95 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))];
        const rawHz = 1000 / avg;
        const standardRates = [60, 90, 120, 144, 165, 240];
        const snappedHz = standardRates.reduce((best, candidate) =>
          Math.abs(candidate - rawHz) < Math.abs(best - rawHz) ? candidate : best
        , Math.round(rawHz));
        const hz = Math.abs(snappedHz - rawHz) <= 3.5 ? snappedHz : Math.round(rawHz * 10) / 10;
        const targetFrameMs = 1000 / hz;
        const droppedFrames = deltas.filter((d) => d > targetFrameMs * 1.45).length;

        resolve({
          hz,
          avgFrameMs: Math.round(avg * 100) / 100,
          p95FrameMs: Math.round(p95 * 100) / 100,
          droppedFrames,
          sampleFrames: deltas.length,
        });
      }
    }

    requestAnimationFrame(step);
  });
}

export function playBreakChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const notes = [587.33, 880];
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.14);
      gain.gain.setValueAtTime(0.001, now + idx * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.14, now + idx * 0.14 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.14 + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.14);
      osc.stop(now + idx * 0.14 + 0.36);
    });
    if (navigator.vibrate) {
      navigator.vibrate([120, 60, 120]);
    }
  } catch {
    // Ignore audio context restriction errors
  }
}

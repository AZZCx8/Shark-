import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Rocket,
  SlidersHorizontal,
  Activity,
  Cpu,
  Settings as SettingsIcon,
  Download,
  WifiOff,
} from 'lucide-react';
import type { AppTab, DeviceTelemetry, GameItem, Language, ThemeMode } from './types/shark';
import { translations } from './i18n/translations';
import { DEFAULT_GAMES } from './data/defaultGames';
import {
  collectDeviceTelemetry,
  launchNativeOrIntentGame,
} from './services/androidBridge';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';
import { SharkLogo } from './components/SharkLogo';
import { BoosterLibraryView } from './components/BoosterLibraryView';
import { GamingModeView } from './components/GamingModeView';
import { NetworkToolsView } from './components/NetworkToolsView';
import { PerformanceDeviceView } from './components/PerformanceDeviceView';
import { SettingsView } from './components/SettingsView';
import { AddGameModal } from './components/AddGameModal';
import { ActiveSessionModal } from './components/ActiveSessionModal';

const STORAGE_GAMES_KEY = 'shark_boost_games_v1';
const STORAGE_LANG_KEY = 'shark_boost_lang_v1';
const STORAGE_THEME_KEY = 'shark_boost_theme_v1';

interface WakeLockSentinelLike {
  released: boolean;
  release: () => Promise<void>;
  addEventListener?: (type: string, listener: () => void) => void;
}

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_LANG_KEY);
    return saved === 'en' || saved === 'ar' ? saved : 'ar';
  });

  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem(STORAGE_THEME_KEY);
    return saved === 'light' || saved === 'dark' ? saved : 'dark';
  });

  const [activeTab, setActiveTab] = useState<AppTab>('booster');

  const [games, setGames] = useState<GameItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_GAMES_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback to starter games
    }
    return DEFAULT_GAMES;
  });

  const [telemetry, setTelemetry] = useState<DeviceTelemetry>({
    platform: 'web',
    cpuCores: null,
    deviceMemoryGb: null,
    nativeAvailMemMb: null,
    nativeTotalMemMb: null,
    storageUsedMb: null,
    storageQuotaMb: null,
    batteryPercent: null,
    batteryCharging: null,
    batteryTempC: null,
    powerSaveMode: null,
    dndAccessGranted: null,
    dndActive: null,
    connectionType: null,
    connectionDownlinkMbps: null,
    connectionRttMs: null,
    connectionSaveData: null,
  });

  const [showAddModal, setShowAddModal] = useState(false);
  const [editingGame, setEditingGame] = useState<GameItem | null>(null);
  const [activeSession, setActiveSession] = useState<{
    game: GameItem;
    mode: 'native' | 'url' | 'intent' | 'session-only';
  } | null>(null);

  const wakeLockRef = useRef<WakeLockSentinelLike | null>(null);
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const wakeLockSupported =
    typeof navigator !== 'undefined' && 'wakeLock' in navigator;

  const isOnline = useOnlineStatus();
  const { isInstallable, install } = usePWAInstall();

  const t = translations[lang];

  useEffect(() => {
    localStorage.setItem(STORAGE_LANG_KEY, lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    localStorage.setItem(STORAGE_THEME_KEY, theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem(STORAGE_GAMES_KEY, JSON.stringify(games));
  }, [games]);

  const refreshTelemetry = useCallback(async () => {
    const data = await collectDeviceTelemetry();
    setTelemetry(data);
  }, []);

  useEffect(() => {
    refreshTelemetry();
  }, [refreshTelemetry]);

  const acquireWakeLock = useCallback(async () => {
    if (!wakeLockSupported) return false;
    try {
      const nav = navigator as Navigator & {
        wakeLock: { request: (type: 'screen') => Promise<WakeLockSentinelLike> };
      };
      const sentinel = await nav.wakeLock.request('screen');
      wakeLockRef.current = sentinel;
      setWakeLockActive(true);
      sentinel.addEventListener?.('release', () => {
        setWakeLockActive(false);
      });
      return true;
    } catch {
      setWakeLockActive(false);
      return false;
    }
  }, [wakeLockSupported]);

  const releaseWakeLock = useCallback(async () => {
    try {
      if (wakeLockRef.current && !wakeLockRef.current.released) {
        await wakeLockRef.current.release();
      }
    } catch {
      // Ignore release errors
    } finally {
      wakeLockRef.current = null;
      setWakeLockActive(false);
    }
  }, []);

  const handleToggleWakeLock = useCallback(() => {
    if (wakeLockActive) {
      releaseWakeLock();
    } else {
      acquireWakeLock();
    }
  }, [wakeLockActive, acquireWakeLock, releaseWakeLock]);

  const handleLaunchGame = async (game: GameItem) => {
    if (game.profile.keepScreenAwake && !wakeLockActive) {
      await acquireWakeLock();
    }

    const updatedTime = Date.now();
    setGames((prev) =>
      prev.map((item) =>
        item.id === game.id ? { ...item, lastLaunchedAt: updatedTime } : item
      )
    );

    const launchRes = await launchNativeOrIntentGame(game);
    if (launchRes.mode !== 'native') {
      setActiveSession({ game, mode: launchRes.mode });
    }
  };

  const handleSaveGame = (game: GameItem) => {
    setGames((prev) => {
      const exists = prev.some((g) => g.id === game.id);
      if (exists) {
        return prev.map((g) => (g.id === game.id ? game : g));
      }
      return [game, ...prev];
    });
    setShowAddModal(false);
    setEditingGame(null);
  };

  const handleDeleteGame = (id: string) => {
    setGames((prev) => prev.filter((g) => g.id !== id));
  };

  const handleTogglePin = (id: string) => {
    setGames((prev) =>
      prev.map((g) => (g.id === id ? { ...g, isPinned: !g.isPinned } : g))
    );
  };

  const handleMergeNativeGames = (detected: GameItem[]) => {
    setGames((prev) => {
      const byPkg = new Map(prev.map((g) => [g.packageName, g]));
      for (const item of detected) {
        if (!byPkg.has(item.packageName)) {
          byPkg.set(item.packageName, item);
        }
      }
      return Array.from(byPkg.values());
    });
  };

  const handleResetData = () => {
    setGames(DEFAULT_GAMES);
    setLang('ar');
    setTheme('dark');
    localStorage.removeItem(STORAGE_GAMES_KEY);
  };

  const navItems: Array<{
    id: AppTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'booster', label: t.nav.booster, icon: Rocket },
    { id: 'gaming', label: t.nav.gaming, icon: SlidersHorizontal },
    { id: 'network', label: t.nav.network, icon: Activity },
    { id: 'performance', label: t.nav.performance, icon: Cpu },
    { id: 'settings', label: t.nav.settings, icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#05070B] text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row">
      {/* Desktop Sidebar Rail */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 border-e border-slate-200 dark:border-white/10 bg-white dark:bg-[#080C14] p-5 justify-between sticky top-0 h-screen">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <SharkLogo size={42} variant="artwork" />
            <div className="min-w-0">
              <span className="font-display text-lg font-extrabold tracking-tight text-slate-900 dark:text-white block truncate">
                {t.appName}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate">
                {t.appSubtitle}
              </span>
            </div>
          </div>

          <nav className="space-y-1.5" aria-label="Main navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full min-h-[46px] px-3.5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-3 transition-colors ${
                    active
                      ? 'bg-[#00A3FF] text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="space-y-2.5 pt-4 border-t border-slate-200 dark:border-white/10">
          {isInstallable && (
            <button
              type="button"
              onClick={install}
              className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-[#00A3FF]/15 text-[#00A3FF] hover:bg-[#00A3FF]/25 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>{t.settings.pwaInstallBtn}</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
            className="w-full min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:border-[#00A3FF] transition-colors"
          >
            {lang === 'ar' ? 'Switch to English' : 'التبديل إلى العربية'}
          </button>
        </div>
      </aside>

      {/* Mobile Top App Bar (compact 56px) */}
      <header className="lg:hidden sticky top-0 z-30 h-14 px-4 bg-white/90 dark:bg-[#05070B]/90 backdrop-blur-md border-b border-slate-200 dark:border-white/10 flex items-center justify-between gap-4 pt-safe">
        <div className="flex items-center gap-2.5 min-w-0">
          <SharkLogo size={32} variant="svg" />
          <span className="font-display text-base font-extrabold tracking-tight text-slate-900 dark:text-white whitespace-nowrap truncate">
            {t.appName}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {isInstallable && (
            <button
              type="button"
              onClick={install}
              aria-label={t.settings.pwaInstallBtn}
              className="min-h-[40px] min-w-[40px] px-2.5 rounded-xl bg-[#00A3FF] text-white text-xs font-semibold flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            type="button"
            onClick={() => setLang((prev) => (prev === 'ar' ? 'en' : 'ar'))}
            className="min-h-[40px] px-3 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-mono font-semibold text-slate-700 dark:text-slate-200"
          >
            {lang === 'ar' ? 'EN' : 'AR'}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 lg:pb-10">
        {!isOnline && (
          <div className="mb-5 rounded-xl bg-amber-500/15 border border-amber-500/30 px-4 py-2.5 text-xs font-medium text-amber-600 dark:text-amber-300 flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>{t.common.offlineBanner}</span>
          </div>
        )}

        {activeTab === 'booster' && (
          <BoosterLibraryView
            t={t}
            lang={lang}
            games={games}
            onLaunchGame={handleLaunchGame}
            onAddClick={() => {
              setEditingGame(null);
              setShowAddModal(true);
            }}
            onEditClick={(game) => {
              setEditingGame(game);
              setShowAddModal(true);
            }}
            onDeleteGame={handleDeleteGame}
            onTogglePin={handleTogglePin}
            onMergeNativeGames={handleMergeNativeGames}
          />
        )}

        {activeTab === 'gaming' && (
          <GamingModeView
            t={t}
            lang={lang}
            wakeLockActive={wakeLockActive}
            wakeLockSupported={wakeLockSupported}
            onToggleWakeLock={handleToggleWakeLock}
          />
        )}

        {activeTab === 'network' && (
          <NetworkToolsView t={t} lang={lang} telemetry={telemetry} />
        )}

        {activeTab === 'performance' && (
          <PerformanceDeviceView
            t={t}
            lang={lang}
            telemetry={telemetry}
            onRefreshTelemetry={refreshTelemetry}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            t={t}
            lang={lang}
            theme={theme}
            onChangeLang={setLang}
            onChangeTheme={setTheme}
            onResetData={handleResetData}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Thumb Navigation (64px) */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 pb-safe bg-white/95 dark:bg-[#080C14]/95 backdrop-blur-md border-t border-slate-200 dark:border-white/10 grid grid-cols-5 items-center"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[48px] flex flex-col items-center justify-center gap-1 transition-colors ${
                active
                  ? 'text-[#00A3FF]'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[11px] font-semibold tracking-tight truncate max-w-[68px]">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Modals */}
      {showAddModal && (
        <AddGameModal
          t={t}
          lang={lang}
          initialGame={editingGame}
          onClose={() => {
            setShowAddModal(false);
            setEditingGame(null);
          }}
          onSave={handleSaveGame}
        />
      )}

      {activeSession && (
        <ActiveSessionModal
          t={t}
          game={activeSession.game}
          wakeLockActive={wakeLockActive}
          launchMode={activeSession.mode}
          onEndSession={() => setActiveSession(null)}
        />
      )}
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import {
  Sun,
  Gauge,
  Timer,
  BellOff,
  Wifi,
  Smartphone,
  BatteryCharging,
  ExternalLink,
} from 'lucide-react';
import type { FrameCadenceResult, Language } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import {
  measureDisplayCadence,
  openAndroidSetting,
  playBreakChime,
  toggleNativeDnd,
} from '../services/androidBridge';
import { AimSensLab } from './AimSensLab';

interface GamingModeViewProps {
  t: TranslationSet;
  lang: Language;
  wakeLockActive: boolean;
  wakeLockSupported: boolean;
  onToggleWakeLock: () => void;
}

export const GamingModeView: React.FC<GamingModeViewProps> = ({
  t,
  lang,
  wakeLockActive,
  wakeLockSupported,
  onToggleWakeLock,
}) => {
  const [subTab, setSubTab] = useState<'controls' | 'aim'>('controls');
  const [probing, setProbing] = useState(false);
  const [cadence, setCadence] = useState<FrameCadenceResult | null>(null);

  const [timerMinutes, setTimerMinutes] = useState(30);
  const [remainingSec, setRemainingSec] = useState<number | null>(null);
  const [shortcutFeedback, setShortcutFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (remainingSec === null) return;
    if (remainingSec <= 0) {
      playBreakChime();
      setRemainingSec(null);
      return;
    }
    const id = window.setInterval(() => {
      setRemainingSec((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, [remainingSec]);

  const handleRunProbe = async () => {
    if (probing) return;
    setProbing(true);
    const result = await measureDisplayCadence(120);
    setCadence(result);
    setProbing(false);
  };

  const handleToggleTimer = () => {
    if (remainingSec !== null) {
      setRemainingSec(null);
    } else {
      setRemainingSec(timerMinutes * 60);
    }
  };

  const handleShortcut = async (
    target: 'dnd' | 'wifi' | 'display' | 'battery'
  ) => {
    if (target === 'dnd') {
      const nativeRes = await toggleNativeDnd(true);
      if (nativeRes.supported) {
        setShortcutFeedback(
          nativeRes.permissionRequired
            ? t.gaming.shortcutDndDesc
            : `${t.gaming.shortcutFeedback}: ${t.gaming.shortcutDnd}`
        );
        return;
      }
    }
    const res = await openAndroidSetting(target);
    if (res.mode === 'intent' && res.intentUri) {
      window.location.href = res.intentUri;
      return;
    }
    setShortcutFeedback(t.gaming.webIntentInfo);
  };

  const formattedRemaining =
    remainingSec !== null
      ? `${String(Math.floor(remainingSec / 60)).padStart(2, '0')}:${String(
          remainingSec % 60
        ).padStart(2, '0')}`
      : null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white text-balance">
            {t.gaming.title}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {t.gaming.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 self-start">
          <button
            type="button"
            onClick={() => setSubTab('controls')}
            className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'controls'
                ? 'bg-white dark:bg-[#00A3FF] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            {lang === 'ar' ? 'أدوات الجلسة' : 'Session Controls'}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('aim')}
            className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'aim'
                ? 'bg-white dark:bg-[#00A3FF] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            {lang === 'ar' ? 'التصويب والحساسية' : 'Aim & Sensitivity'}
          </button>
        </div>
      </div>

      {subTab === 'aim' ? (
        <AimSensLab lang={lang} />
      ) : (
        <>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Wake Lock Control */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 flex flex-col justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Sun className="w-5 h-5 text-[#00A3FF]" />
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                {!wakeLockSupported
                  ? t.common.unsupported
                  : wakeLockActive
                  ? t.common.active
                  : t.common.inactive}
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t.gaming.wakeLockTitle}
            </h2>
            <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              {t.gaming.wakeLockDesc}
            </p>
          </div>

          <button
            type="button"
            disabled={!wakeLockSupported}
            onClick={onToggleWakeLock}
            className={`w-full min-h-[46px] px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors disabled:opacity-50 ${
              wakeLockActive
                ? 'bg-slate-900 dark:bg-white/15 text-white hover:bg-slate-800'
                : 'bg-[#00A3FF] hover:bg-[#0284C7] text-white'
            }`}
          >
            {wakeLockActive ? t.gaming.wakeLockBtnOff : t.gaming.wakeLockBtnOn}
          </button>
        </section>

        {/* Real Display Refresh Rate Probe */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 flex flex-col justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Gauge className="w-5 h-5 text-[#00A3FF]" />
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400" dir="ltr">
                requestAnimationFrame
              </span>
            </div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t.gaming.refreshProbeTitle}
            </h2>
            <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              {t.gaming.refreshProbeDesc}
            </p>

            {cadence && (
              <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
                  <span className="text-slate-500 dark:text-slate-400 block">
                    {t.gaming.measuredHz}
                  </span>
                  <span className="font-mono font-bold text-sm text-[#00A3FF] tabular-nums" dir="ltr">
                    {cadence.hz} Hz
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
                  <span className="text-slate-500 dark:text-slate-400 block">
                    {t.gaming.avgFrame}
                  </span>
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white tabular-nums" dir="ltr">
                    {cadence.avgFrameMs} ms
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
                  <span className="text-slate-500 dark:text-slate-400 block">
                    {t.gaming.p95Frame}
                  </span>
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white tabular-nums" dir="ltr">
                    {cadence.p95FrameMs} ms
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
                  <span className="text-slate-500 dark:text-slate-400 block">
                    {t.gaming.dropped}
                  </span>
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white tabular-nums" dir="ltr">
                    {cadence.droppedFrames}/{cadence.sampleFrames}
                  </span>
                </div>
              </div>
            )}
          </div>

          <button
            type="button"
            disabled={probing}
            onClick={handleRunProbe}
            className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold transition-colors disabled:opacity-60"
          >
            {probing ? t.gaming.probing : t.gaming.runProbe}
          </button>
        </section>

        {/* Session Break Timer */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 flex flex-col justify-between gap-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Timer className="w-5 h-5 text-[#00A3FF]" />
              {formattedRemaining && (
                <span className="font-mono text-sm font-bold text-[#00A3FF] tabular-nums" dir="ltr">
                  {formattedRemaining}
                </span>
              )}
            </div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t.gaming.timerTitle}
            </h2>
            <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-400">
              {t.gaming.timerDesc}
            </p>

            <div className="flex items-center gap-2 pt-1">
              {[20, 30, 45, 60].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  disabled={remainingSec !== null}
                  onClick={() => setTimerMinutes(mins)}
                  className={`flex-1 min-h-[40px] rounded-xl text-xs font-mono font-semibold border transition-colors ${
                    timerMinutes === mins
                      ? 'border-[#00A3FF] bg-[#00A3FF]/15 text-[#00A3FF]'
                      : 'border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {mins}m
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={handleToggleTimer}
            className={`w-full min-h-[46px] px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
              remainingSec !== null
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-slate-900 dark:bg-[#00A3FF] hover:bg-slate-800 dark:hover:bg-[#0284C7] text-white'
            }`}
          >
            {remainingSec !== null ? t.gaming.stopTimer : t.gaming.startTimer}
          </button>
        </section>
      </div>

      {/* Android System Shortcuts */}
      <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
        <div className="space-y-1">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t.gaming.shortcutsTitle}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            {t.gaming.shortcutsDesc}
          </p>
        </div>

        {shortcutFeedback && (
          <div className="rounded-xl bg-sky-500/10 border border-sky-500/25 px-3.5 py-2.5 text-xs text-slate-700 dark:text-slate-200">
            {shortcutFeedback}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            {
              key: 'dnd' as const,
              icon: BellOff,
              title: t.gaming.shortcutDnd,
              desc: t.gaming.shortcutDndDesc,
            },
            {
              key: 'wifi' as const,
              icon: Wifi,
              title: t.gaming.shortcutWifi,
              desc: t.gaming.shortcutWifiDesc,
            },
            {
              key: 'display' as const,
              icon: Smartphone,
              title: t.gaming.shortcutDisplay,
              desc: t.gaming.shortcutDisplayDesc,
            },
            {
              key: 'battery' as const,
              icon: BatteryCharging,
              title: t.gaming.shortcutBattery,
              desc: t.gaming.shortcutBatteryDesc,
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => handleShortcut(item.key)}
                className="min-h-[64px] p-4 rounded-2xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-start flex items-center justify-between gap-3 transition-colors"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-[#00A3FF]/10 text-[#00A3FF] flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white">
                      {item.title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">
                      {item.desc}
                    </p>
                  </div>
                </div>
                <ExternalLink className="w-4 h-4 text-slate-400 shrink-0" />
              </button>
            );
          })}
        </div>
      </section>
        </>
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { ExternalLink, ShieldCheck, Timer, Activity, X } from 'lucide-react';
import type { FrameCadenceResult, GameItem } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import {
  buildAndroidLaunchIntentUri,
  isAndroidBrowser,
  measureDisplayCadence,
} from '../services/androidBridge';

interface ActiveSessionModalProps {
  t: TranslationSet;
  game: GameItem;
  wakeLockActive: boolean;
  launchMode: 'native' | 'url' | 'intent' | 'session-only';
  onEndSession: () => void;
}

export const ActiveSessionModal: React.FC<ActiveSessionModalProps> = ({
  t,
  game,
  wakeLockActive,
  launchMode,
  onEndSession,
}) => {
  const [elapsedSec, setElapsedSec] = useState(0);
  const [cadence, setCadence] = useState<FrameCadenceResult | null>(null);
  const [quickPingMs, setQuickPingMs] = useState<number | null>(null);

  useEffect(() => {
    const id = window.setInterval(() => {
      setElapsedSec((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (game.profile.measureFrameCadence) {
      measureDisplayCadence(90).then(setCadence);
    }
    if (game.profile.checkNetworkBeforeLaunch) {
      const start = performance.now();
      fetch(`/api/probe?t=${Date.now()}`, { cache: 'no-store' })
        .then((res) => {
          if (res.ok) setQuickPingMs(Math.round(performance.now() - start));
        })
        .catch(() => {
          setQuickPingMs(null);
        });
    }
  }, [game]);

  const mins = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
  const secs = String(elapsedSec % 60).padStart(2, '0');
  const androidIntentUri = buildAndroidLaunchIntentUri(game.packageName);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-[#00A3FF]/30 p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#00A3FF] tracking-wide">
            {t.booster.session.title}
          </span>
          <button
            type="button"
            onClick={onEndSession}
            aria-label={t.common.close}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-4">
          <img
            src={game.iconUrl}
            alt={game.name}
            referrerPolicy="no-referrer"
            className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-white/10 shrink-0"
          />
          <div className="min-w-0">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white truncate">
              {game.name}
            </h3>
            <p className="text-xs font-mono text-slate-500 dark:text-slate-400 truncate" dir="ltr">
              {game.packageName}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
              <Timer className="w-3.5 h-3.5 text-[#00A3FF]" />
              <span>{t.booster.session.elapsed}</span>
            </div>
            <p className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums" dir="ltr">
              {mins}:{secs}
            </p>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
              <Activity className="w-3.5 h-3.5 text-[#00A3FF]" />
              <span>{t.booster.session.cadence}</span>
            </div>
            <p className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums" dir="ltr">
              {cadence ? `${cadence.hz} Hz` : '...'}
            </p>
          </div>
        </div>

        <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
          <div className="flex items-center justify-between py-2 border-b border-slate-200 dark:border-white/10">
            <span className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#00A3FF]" />
              <span>{wakeLockActive ? t.booster.session.wakeLockActive : t.booster.session.wakeLockOff}</span>
            </span>
            <span className="font-mono">{wakeLockActive ? 'ON' : 'OFF'}</span>
          </div>
          {quickPingMs !== null && (
            <div className="flex items-center justify-between py-2 border-b border-slate-200 dark:border-white/10">
              <span>{t.network.avgLatency}</span>
              <span className="font-mono tabular-nums" dir="ltr">{quickPingMs} ms</span>
            </div>
          )}
        </div>

        <p className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">
          {t.booster.session.honestyNote}
        </p>

        <div className="flex flex-col sm:flex-row gap-2.5">
          {game.launchUrl && (
            <a
              href={game.launchUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 min-h-[46px] px-4 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>{t.booster.session.openUrl}</span>
            </a>
          )}
          {(isAndroidBrowser() || launchMode === 'intent') && !game.launchUrl && (
            <a
              href={androidIntentUri}
              className="flex-1 min-h-[46px] px-4 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>{t.booster.session.openAndroidIntent}</span>
            </a>
          )}
          <button
            type="button"
            onClick={onEndSession}
            className="flex-1 min-h-[46px] px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/15 text-slate-900 dark:text-white text-sm font-semibold transition-colors"
          >
            {t.booster.session.endSession}
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useMemo, useState } from 'react';
import {
  Play,
  Plus,
  Search,
  Pin,
  PinOff,
  Pencil,
  Trash2,
  ScanSearch,
  Gamepad2,
} from 'lucide-react';
import type { GameCategory, GameItem, Language } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import { scanInstalledAndroidGames } from '../services/androidBridge';

interface BoosterLibraryViewProps {
  t: TranslationSet;
  lang: Language;
  games: GameItem[];
  onLaunchGame: (game: GameItem) => void;
  onAddClick: () => void;
  onEditClick: (game: GameItem) => void;
  onDeleteGame: (id: string) => void;
  onTogglePin: (id: string) => void;
  onMergeNativeGames: (detected: GameItem[]) => void;
}

export const BoosterLibraryView: React.FC<BoosterLibraryViewProps> = ({
  t,
  lang,
  games,
  onLaunchGame,
  onAddClick,
  onEditClick,
  onDeleteGame,
  onTogglePin,
  onMergeNativeGames,
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<GameCategory | 'all'>('all');
  const [scanMessage, setScanMessage] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);

  const pinnedGames = useMemo(() => games.filter((g) => g.isPinned), [games]);

  const filteredGames = useMemo(() => {
    const q = search.trim().toLowerCase();
    return games.filter((g) => {
      const matchesCat = categoryFilter === 'all' || g.category === categoryFilter;
      const matchesQuery =
        !q ||
        g.name.toLowerCase().includes(q) ||
        g.packageName.toLowerCase().includes(q);
      return matchesCat && matchesQuery;
    });
  }, [games, search, categoryFilter]);

  const handleScan = async () => {
    setScanning(true);
    setScanMessage(null);
    const result = await scanInstalledAndroidGames();
    setScanning(false);
    if (result.source === 'native' && result.games.length > 0) {
      onMergeNativeGames(result.games);
      setScanMessage(`${t.booster.scanSuccess} (${result.games.length})`);
    } else {
      setScanMessage(t.booster.scanWebNotice);
    }
  };

  const formatLastPlayed = (ts?: number) => {
    if (!ts) return t.booster.neverPlayed;
    return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-SA' : 'en-US', {
      hour: '2-digit',
      minute: '2-digit',
      month: 'short',
      day: 'numeric',
    }).format(new Date(ts));
  };

  const categories: Array<GameCategory | 'all'> = [
    'all',
    'shooter',
    'racing',
    'rpg',
    'moba',
    'sandbox',
    'other',
  ];

  return (
    <div className="space-y-6">
      {/* Header & Primary Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white text-balance">
            {t.booster.heroTitle}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {t.booster.heroDesc}
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleScan}
            disabled={scanning}
            className="min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#0D131F] text-slate-700 dark:text-slate-200 hover:border-[#00A3FF] text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <ScanSearch className="w-4 h-4 text-[#00A3FF]" />
            <span>{t.booster.scanNative}</span>
          </button>

          <button
            type="button"
            onClick={onAddClick}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{t.booster.addGame}</span>
          </button>
        </div>
      </div>

      {scanMessage && (
        <div className="rounded-2xl bg-sky-500/10 border border-sky-500/25 px-4 py-3 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          {scanMessage}
        </div>
      )}

      {/* Quick Launch Pinned Section */}
      {pinnedGames.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t.booster.pinnedTitle}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {pinnedGames.map((game) => (
              <div
                key={`pin-${game.id}`}
                className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4 flex items-center justify-between gap-3 hover:border-[#00A3FF]/50 transition-colors"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <img
                    src={game.iconUrl}
                    alt={game.name}
                    referrerPolicy="no-referrer"
                    className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-slate-200 dark:border-white/10"
                  />
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {game.name}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {t.booster.categories[game.category]} ·{' '}
                      {game.profile.keepScreenAwake ? t.booster.profileSummary.wakeLock : t.booster.profileSummary.frameCheck}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onLaunchGame(game)}
                  aria-label={`${t.common.launch} ${game.name}`}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{t.common.launch}</span>
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Full Organized Game Library */}
      <section className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t.booster.libraryTitle} ({filteredGames.length})
          </h2>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.booster.searchPlaceholder}
              className="w-full min-h-[44px] ps-10 pe-3.5 py-2 rounded-xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
            />
          </div>
        </div>

        {/* Category Segmented Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {categories.map((cat) => {
            const active = categoryFilter === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#00A3FF] text-white'
                    : 'bg-white dark:bg-[#0D131F] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-white/10 hover:border-[#00A3FF]/40'
                }`}
              >
                {t.booster.categories[cat]}
              </button>
            );
          })}
        </div>

        {filteredGames.length === 0 ? (
          <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-10 text-center space-y-3">
            <Gamepad2 className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {t.booster.emptyLibrary}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredGames.map((game) => (
              <article
                key={game.id}
                className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4 flex flex-col justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <img
                    src={game.iconUrl}
                    alt={game.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-2xl object-cover shrink-0 border border-slate-200 dark:border-white/10"
                  />
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white truncate">
                      {game.name}
                    </h3>
                    <p
                      className="text-xs font-mono text-slate-500 dark:text-slate-400 truncate mt-0.5"
                      dir="ltr"
                    >
                      {game.packageName}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5">
                      {t.booster.categories[game.category]} · {t.booster.lastPlayed}:{' '}
                      {formatLastPlayed(game.lastLaunchedAt)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-white/5">
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onTogglePin(game.id)}
                      title={game.isPinned ? t.booster.unpin : t.booster.pin}
                      aria-label={game.isPinned ? t.booster.unpin : t.booster.pin}
                      className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl transition-colors ${
                        game.isPinned
                          ? 'text-[#00A3FF] bg-[#00A3FF]/10'
                          : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'
                      }`}
                    >
                      {game.isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => onEditClick(game)}
                      title={t.common.edit}
                      aria-label={t.common.edit}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => onDeleteGame(game.id)}
                      title={t.common.delete}
                      aria-label={t.common.delete}
                      className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => onLaunchGame(game)}
                    className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-[#00A3FF] hover:bg-slate-800 dark:hover:bg-[#0284C7] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{t.common.launch}</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

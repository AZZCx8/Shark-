import React, { useState } from 'react';
import {
  Languages,
  Moon,
  Sun,
  Download,
  Smartphone,
  RotateCcw,
  PackageCheck,
} from 'lucide-react';
import type { Language, ThemeMode } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface SettingsViewProps {
  t: TranslationSet;
  lang: Language;
  theme: ThemeMode;
  onChangeLang: (lang: Language) => void;
  onChangeTheme: (theme: ThemeMode) => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  t,
  lang,
  theme,
  onChangeLang,
  onChangeTheme,
  onResetData,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleDownloadAndroidZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      const response = await fetch('/api/export-android');
      if (!response.ok) throw new Error('Export failed');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'shark-boost-android-project.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } finally {
      setDownloadingZip(false);
    }
  };

  const handleReset = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      window.setTimeout(() => setConfirmReset(false), 3500);
      return;
    }
    onResetData();
    setConfirmReset(false);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-1.5">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white text-balance">
          {t.settings.title}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          {t.settings.subtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Language & Theme */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-5">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2">
              <Languages className="w-5 h-5 text-[#00A3FF]" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.settings.languageTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.settings.languageDesc}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => onChangeLang('ar')}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
                  lang === 'ar'
                    ? 'bg-[#00A3FF] text-white border-[#00A3FF]'
                    : 'bg-slate-50 dark:bg-[#070B12] text-slate-700 dark:text-slate-200 border-slate-200 dark:border-white/10'
                }`}
              >
                {t.common.arabic}
              </button>
              <button
                type="button"
                onClick={() => onChangeLang('en')}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border transition-colors ${
                  lang === 'en'
                    ? 'bg-[#00A3FF] text-white border-[#00A3FF]'
                    : 'bg-slate-50 dark:bg-[#070B12] text-slate-700 dark:text-slate-200 border-slate-200 dark:border-white/10'
                }`}
              >
                {t.common.english}
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-white/5 space-y-2.5">
            <div className="flex items-center gap-2">
              {theme === 'dark' ? (
                <Moon className="w-5 h-5 text-[#00A3FF]" />
              ) : (
                <Sun className="w-5 h-5 text-[#00A3FF]" />
              )}
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.settings.themeTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.settings.themeDesc}
            </p>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => onChangeTheme('dark')}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border flex items-center justify-center gap-2 transition-colors ${
                  theme === 'dark'
                    ? 'bg-[#00A3FF] text-white border-[#00A3FF]'
                    : 'bg-slate-50 dark:bg-[#070B12] text-slate-700 dark:text-slate-200 border-slate-200 dark:border-white/10'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{t.settings.darkMode}</span>
              </button>
              <button
                type="button"
                onClick={() => onChangeTheme('light')}
                className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border flex items-center justify-center gap-2 transition-colors ${
                  theme === 'light'
                    ? 'bg-[#00A3FF] text-white border-[#00A3FF]'
                    : 'bg-slate-50 dark:bg-[#070B12] text-slate-700 dark:text-slate-200 border-slate-200 dark:border-white/10'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>{t.settings.lightMode}</span>
              </button>
            </div>
          </div>
        </section>

        {/* PWA Install & Reset */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 flex flex-col justify-between gap-5">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-[#00A3FF]" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.settings.pwaTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {t.settings.pwaDesc}
            </p>

            {isInstalled ? (
              <p className="text-xs font-semibold text-[#00A3FF]">
                {t.settings.pwaInstalled}
              </p>
            ) : isInstallable ? (
              <button
                type="button"
                onClick={install}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold flex items-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>{t.settings.pwaInstallBtn}</span>
              </button>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isIOS ? t.settings.pwaManualHint : t.settings.pwaManualHint}
              </p>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-white/5 space-y-2.5">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t.settings.resetTitle}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t.settings.resetDesc}
            </p>
            <button
              type="button"
              onClick={handleReset}
              className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 border transition-colors ${
                confirmReset
                  ? 'bg-rose-600 text-white border-rose-600'
                  : 'border-rose-500/40 text-rose-500 hover:bg-rose-500/10'
              }`}
            >
              <RotateCcw className="w-4 h-4" />
              <span>
                {confirmReset ? t.settings.resetConfirm : t.settings.resetBtn}
              </span>
            </button>
          </div>
        </section>
      </div>

      {/* Android APK Project Export */}
      <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <PackageCheck className="w-5 h-5 text-[#00A3FF]" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.settings.apkTitle}
              </h2>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed">
              {t.settings.apkDesc}
            </p>
          </div>

          <button
            type="button"
            disabled={downloadingZip}
            onClick={handleDownloadAndroidZip}
            className="min-h-[46px] px-5 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold flex items-center justify-center gap-2 shrink-0 transition-colors disabled:opacity-60"
          >
            <Download className="w-4 h-4" />
            <span>
              {downloadingZip ? t.settings.apkDownloading : t.settings.apkDownloadBtn}
            </span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-100 dark:border-white/5">
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#070B12]">
            <span className="text-slate-500 dark:text-slate-400">{t.settings.apkPackage}</span>
            <span className="font-mono font-semibold text-slate-900 dark:text-white" dir="ltr">
              com.sharkboost.gaming
            </span>
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-[#070B12]">
            <span className="text-slate-500 dark:text-slate-400">{t.settings.apkTargetSdk}</span>
            <span className="font-mono font-semibold text-slate-900 dark:text-white" dir="ltr">
              Android 15 (API 35) · minSdk 24
            </span>
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-200">
            {t.settings.apkStepsTitle}
          </p>
          <ol className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400 font-mono" dir="ltr">
            {t.settings.apkSteps.map((step, i) => (
              <li
                key={step}
                className="p-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5"
              >
                {i + 1}. {step}
              </li>
            ))}
          </ol>
        </div>
      </section>
    </div>
  );
};

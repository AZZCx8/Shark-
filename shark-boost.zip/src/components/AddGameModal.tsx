import React, { useState } from 'react';
import { X, Upload, Plus } from 'lucide-react';
import type { GameCategory, GameItem, GameProfile, Language } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import { DEFAULT_PROFILE, GAME_ICON_PRESETS, POPULAR_ANDROID_CATALOG } from '../data/defaultGames';

interface AddGameModalProps {
  t: TranslationSet;
  lang: Language;
  initialGame?: GameItem | null;
  onClose: () => void;
  onSave: (game: GameItem) => void;
}

export const AddGameModal: React.FC<AddGameModalProps> = ({
  t,
  lang,
  initialGame,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState(initialGame?.name ?? '');
  const [packageName, setPackageName] = useState(initialGame?.packageName ?? '');
  const [category, setCategory] = useState<GameCategory>(initialGame?.category ?? 'shooter');
  const [launchUrl, setLaunchUrl] = useState(initialGame?.launchUrl ?? '');
  const [iconUrl, setIconUrl] = useState(
    initialGame?.iconUrl ?? GAME_ICON_PRESETS[0].url
  );
  const [profile, setProfile] = useState<GameProfile>(
    initialGame?.profile ?? { ...DEFAULT_PROFILE }
  );

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setIconUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const applyPreset = (preset: (typeof POPULAR_ANDROID_CATALOG)[number]) => {
    setName(preset.name);
    setPackageName(preset.packageName);
    setCategory(preset.category);
    setIconUrl(preset.iconUrl);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = name.trim();
    if (!cleanName) return;
    const cleanPkg =
      packageName.trim() ||
      `com.game.${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'custom'}`;

    const item: GameItem = {
      id: initialGame?.id ?? `${cleanPkg}-${Date.now()}`,
      name: cleanName,
      packageName: cleanPkg,
      category,
      iconUrl,
      launchUrl: launchUrl.trim() || undefined,
      isPinned: initialGame?.isPinned ?? true,
      isNativeDetected: initialGame?.isNativeDetected,
      lastLaunchedAt: initialGame?.lastLaunchedAt,
      profile,
    };
    onSave(item);
  };

  const categories: GameCategory[] = ['shooter', 'racing', 'rpg', 'moba', 'sandbox', 'other'];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full sm:max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white dark:bg-[#0D131F] border-t sm:border border-slate-200 dark:border-white/10 shadow-2xl">
        <div className="sm:hidden w-10 h-1.5 bg-slate-300 dark:bg-white/20 rounded-full mx-auto my-3" />

        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {initialGame ? t.booster.modal.editTitle : t.booster.modal.addTitle}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t.common.close}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          {!initialGame && (
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
                {t.booster.modal.quickPresets}
              </p>
              <div className="flex flex-wrap gap-2">
                {POPULAR_ANDROID_CATALOG.map((preset) => (
                  <button
                    key={preset.packageName}
                    type="button"
                    onClick={() => applyPreset(preset)}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-100 dark:bg-white/5 text-slate-700 dark:text-slate-200 hover:bg-sky-500/15 hover:text-sky-600 dark:hover:text-[#38BDF8] border border-slate-200 dark:border-white/10 transition-colors flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                {t.booster.modal.gameName}
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="PUBG MOBILE"
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                  {t.booster.modal.packageName}
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value)}
                  placeholder={t.booster.modal.packageHint}
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                  {t.booster.modal.category}
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as GameCategory)}
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {t.booster.categories[cat]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
                {t.booster.modal.launchUrl}
              </label>
              <input
                type="url"
                dir="ltr"
                value={launchUrl}
                onChange={(e) => setLaunchUrl(e.target.value)}
                placeholder="https://..."
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
              />
            </div>

            <div>
              <p className="text-sm font-medium text-slate-700 dark:text-slate-200 mb-2">
                {t.booster.modal.iconPick}
              </p>
              <div className="flex items-center gap-3 flex-wrap">
                {GAME_ICON_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setIconUrl(preset.url)}
                    title={lang === 'ar' ? preset.labelAr : preset.labelEn}
                    className={`p-1 rounded-2xl border-2 transition-all ${
                      iconUrl === preset.url
                        ? 'border-[#00A3FF] scale-105'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.labelEn}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-xl object-cover"
                    />
                  </button>
                ))}
                <label className="min-h-[48px] px-3.5 py-2 rounded-xl border border-dashed border-slate-300 dark:border-white/20 text-xs font-medium text-slate-600 dark:text-slate-300 hover:border-[#00A3FF] cursor-pointer flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  <span>{t.booster.modal.uploadIcon}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-white/10 space-y-2.5">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-200">
                {t.booster.modal.sessionOptions}
              </p>

              <label className="flex items-center justify-between min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 cursor-pointer">
                <span className="text-sm text-slate-700 dark:text-slate-200">
                  {t.booster.profileSummary.wakeLock}
                </span>
                <input
                  type="checkbox"
                  checked={profile.keepScreenAwake}
                  onChange={(e) =>
                    setProfile((p) => ({ ...p, keepScreenAwake: e.target.checked }))
                  }
                  className="w-4 h-4 accent-[#00A3FF]"
                />
              </label>

              <label className="flex items-center justify-between min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 cursor-pointer">
                <span className="text-sm text-slate-700 dark:text-slate-200">
                  {t.booster.profileSummary.frameCheck}
                </span>
                <input
                  type="checkbox"
                  checked={profile.measureFrameCadence}
                  onChange={(e) =>
                    setProfile((p) => ({ ...p, measureFrameCadence: e.target.checked }))
                  }
                  className="w-4 h-4 accent-[#00A3FF]"
                />
              </label>

              <label className="flex items-center justify-between min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200 dark:border-white/10 cursor-pointer">
                <span className="text-sm text-slate-700 dark:text-slate-200">
                  {t.booster.profileSummary.netCheck}
                </span>
                <input
                  type="checkbox"
                  checked={profile.checkNetworkBeforeLaunch}
                  onChange={(e) =>
                    setProfile((p) => ({ ...p, checkNetworkBeforeLaunch: e.target.checked }))
                  }
                  className="w-4 h-4 accent-[#00A3FF]"
                />
              </label>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 min-h-[46px] px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 transition-colors"
            >
              {t.common.cancel}
            </button>
            <button
              type="submit"
              className="flex-1 min-h-[46px] px-4 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold transition-colors"
            >
              {t.common.save}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

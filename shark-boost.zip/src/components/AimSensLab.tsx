import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Crosshair, RotateCcw, ShieldAlert, Sliders } from 'lucide-react';
import type { Language } from '../types/shark';

interface AimSensLabProps {
  lang: Language;
}

type ShooterTitle = 'pubg' | 'freefire' | 'codm';
type PlayStyle = 'balanced' | 'aggressive' | 'gyro';

interface TargetPoint {
  x: number;
  y: number;
  r: number;
  spawnedAt: number;
}

export const AimSensLab: React.FC<AimSensLabProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  // Touch Aim & Reflex Drill State
  const [drillActive, setDrillActive] = useState(false);
  const [drillTimeLeft, setDrillTimeLeft] = useState(20);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [reactionTimes, setReactionTimes] = useState<number[]>([]);
  const [target, setTarget] = useState<TargetPoint>({ x: 50, y: 50, r: 22, spawnedAt: 0 });
  const arenaRef = useRef<HTMLDivElement | null>(null);

  // Sensitivity & Recoil-Control Calculator State
  const [gameTitle, setGameTitle] = useState<ShooterTitle>('pubg');
  const [playStyle, setPlayStyle] = useState<PlayStyle>('balanced');
  const [screenHz, setScreenHz] = useState<60 | 90 | 120>(90);
  const [baseTouchScale, setBaseTouchScale] = useState(100);

  const spawnTarget = useCallback(() => {
    const x = 14 + Math.random() * 72;
    const y = 16 + Math.random() * 68;
    setTarget({
      x,
      y,
      r: 20,
      spawnedAt: performance.now(),
    });
  }, []);

  useEffect(() => {
    if (!drillActive) return;
    if (drillTimeLeft <= 0) {
      setDrillActive(false);
      return;
    }
    const id = window.setInterval(() => {
      setDrillTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(id);
  }, [drillActive, drillTimeLeft]);

  const startDrill = () => {
    setHits(0);
    setMisses(0);
    setReactionTimes([]);
    setDrillTimeLeft(20);
    setDrillActive(true);
    spawnTarget();
  };

  const stopDrill = () => {
    setDrillActive(false);
  };

  const handleArenaTap = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!drillActive || !arenaRef.current) return;
    const rect = arenaRef.current.getBoundingClientRect();
    const tapX = ((e.clientX - rect.left) / rect.width) * 100;
    const tapY = ((e.clientY - rect.top) / rect.height) * 100;
    const dx = ((tapX - target.x) / 100) * rect.width;
    const dy = ((tapY - target.y) / 100) * rect.height;
    const dist = Math.hypot(dx, dy);

    if (dist <= target.r + 6) {
      const rt = Math.round(performance.now() - target.spawnedAt);
      setHits((prev) => prev + 1);
      setReactionTimes((prev) => [...prev, rt]);
      spawnTarget();
    } else {
      setMisses((prev) => prev + 1);
    }
  };

  const totalTaps = hits + misses;
  const accuracy = totalTaps > 0 ? Math.round((hits / totalTaps) * 100) : 0;
  const avgReaction =
    reactionTimes.length > 0
      ? Math.round(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length)
      : null;

  // Legitimate mathematical sensitivity ratio calculator (for manual entry inside game settings)
  const factor = (baseTouchScale / 100) * (screenHz === 120 ? 1.06 : screenHz === 90 ? 1.02 : 1.0);
  const styleMult = playStyle === 'aggressive' ? 1.16 : playStyle === 'gyro' ? 0.92 : 1.0;

  const sensProfile =
    gameTitle === 'pubg'
      ? {
          cameraNoScope: Math.round(110 * factor * styleMult),
          adsRedDot: Math.round(52 * factor * styleMult),
          ads3x: Math.round(28 * factor * styleMult),
          ads6x: Math.round(14 * factor * styleMult),
          gyroRedDot: playStyle === 'gyro' ? Math.round(280 * factor) : Math.round(180 * factor),
          gyro4x: playStyle === 'gyro' ? Math.round(175 * factor) : Math.round(115 * factor),
          maxLabel: '300%',
        }
      : gameTitle === 'freefire'
      ? {
          cameraNoScope: Math.min(200, Math.round(165 * factor * styleMult)),
          adsRedDot: Math.min(200, Math.round(140 * factor * styleMult)),
          ads3x: Math.min(200, Math.round(115 * factor * styleMult)),
          ads6x: Math.min(200, Math.round(92 * factor * styleMult)),
          gyroRedDot: Math.min(200, Math.round(125 * factor)),
          gyro4x: Math.min(200, Math.round(95 * factor)),
          maxLabel: '200',
        }
      : {
          cameraNoScope: Math.round(95 * factor * styleMult),
          adsRedDot: Math.round(78 * factor * styleMult),
          ads3x: Math.round(54 * factor * styleMult),
          ads6x: Math.round(34 * factor * styleMult),
          gyroRedDot: playStyle === 'gyro' ? Math.round(165 * factor) : Math.round(105 * factor),
          gyro4x: playStyle === 'gyro' ? Math.round(110 * factor) : Math.round(70 * factor),
          maxLabel: '300',
        };

  return (
    <div className="space-y-6">
      {/* Fair-Play Notice */}
      <div className="rounded-2xl bg-sky-500/10 border border-sky-500/25 p-4 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
        <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          {isAr
            ? 'لأسباب تتعلق بأمان أندرويد واللعب النظيف، لا يوفّر SHARK BOOST تصويباً تلقائياً (Aimbot) أو حقناً في ملفات الألعاب. بدلاً من ذلك، يوفّر مختبر تدريب لمسي حقيقي وحاسبة حساسية تساعدك على تثبيت التصويب بمهارتك دون حظر حسابك.'
            : 'For Android security and fair play, SHARK BOOST does not provide an Aimbot, auto-aim overlay, or game memory injection. Instead, it provides a real touch reflex trainer and sensitivity ratio calculator to help you stabilize your aim legitimately without risking account bans.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Touch Aim & Reflex Drill */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Crosshair className="w-5 h-5 text-[#00A3FF]" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr ? 'مدرب التصويب وردة الفعل (20 ثانية)' : 'Touch Aim & Reflex Trainer (20s)'}
              </h2>
            </div>
            <span className="font-mono text-sm font-bold text-[#00A3FF] tabular-nums" dir="ltr">
              {drillTimeLeft}s
            </span>
          </div>

          <div
            ref={arenaRef}
            onPointerDown={handleArenaTap}
            className="relative w-full h-64 rounded-2xl bg-slate-900 dark:bg-[#05070B] border border-slate-200 dark:border-white/10 overflow-hidden select-none touch-manipulation cursor-crosshair"
          >
            {!drillActive && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center gap-3 bg-black/40">
                <p className="text-xs text-slate-200 max-w-xs">
                  {isAr
                    ? 'اضغط على الدائرة الزرقاء بأسرع ما يمكن لقياس سرعة رد فعلك ودقة لمس الشاشة.'
                    : 'Tap the electric blue targets as fast and accurately as possible to measure real touch reflex and precision.'}
                </p>
                <button
                  type="button"
                  onClick={startDrill}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-sm font-semibold transition-colors"
                >
                  {hits > 0 || misses > 0
                    ? isAr
                      ? 'إعادة التدريب'
                      : 'Restart Drill'
                    : isAr
                    ? 'ابدأ التدريب'
                    : 'Start Drill'}
                </button>
              </div>
            )}

            {drillActive && (
              <div
                style={{
                  left: `${target.x}%`,
                  top: `${target.y}%`,
                  width: `${target.r * 2}px`,
                  height: `${target.r * 2}px`,
                  transform: 'translate(-50%, -50%)',
                }}
                className="absolute rounded-full bg-[#00A3FF]/25 border-2 border-[#00A3FF] flex items-center justify-center pointer-events-none"
              >
                <div className="w-2.5 h-2.5 rounded-full bg-white" />
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2.5 text-center">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'الإصابات' : 'Hits'}
              </span>
              <span className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {hits}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'الدقة' : 'Accuracy'}
              </span>
              <span className="font-mono text-base font-bold text-[#00A3FF] tabular-nums" dir="ltr">
                {accuracy}%
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'متوسط الرد' : 'Avg Reaction'}
              </span>
              <span className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {avgReaction !== null ? `${avgReaction} ms` : '—'}
              </span>
            </div>
          </div>

          {drillActive && (
            <button
              type="button"
              onClick={stopDrill}
              className="w-full min-h-[44px] px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isAr ? 'إيقاف التمرين' : 'Stop Drill'}</span>
            </button>
          )}
        </section>

        {/* Competitive Sensitivity & Recoil Ratio Calculator */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-[#00A3FF]" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isAr ? 'حاسبة الحساسية وتثبيت السلاح' : 'Sensitivity & Recoil Ratio Calculator'}
            </h2>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'pubg' as const, label: 'PUBG Mobile' },
              { id: 'freefire' as const, label: 'Free Fire' },
              { id: 'codm' as const, label: 'COD Mobile' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setGameTitle(item.id)}
                className={`min-h-[42px] px-2.5 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                  gameTitle === item.id
                    ? 'bg-[#00A3FF] text-white border-[#00A3FF]'
                    : 'bg-slate-50 dark:bg-[#070B12] text-slate-700 dark:text-slate-300 border-slate-200 dark:border-white/10'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                {isAr ? 'أسلوب اللعب' : 'Playstyle'}
              </label>
              <select
                value={playStyle}
                onChange={(e) => setPlayStyle(e.target.value as PlayStyle)}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-900 dark:text-white"
              >
                <option value="balanced">{isAr ? 'متوازن للثبات' : 'Balanced Control'}</option>
                <option value="aggressive">{isAr ? 'سريع (مواجهات قريبة)' : 'Fast Close-Range'}</option>
                <option value="gyro">{isAr ? 'جيروسكوب كامل' : 'Full Gyroscope'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                {isAr ? 'تردد شاشة هاتفك' : 'Panel Refresh Rate'}
              </label>
              <select
                value={screenHz}
                onChange={(e) => setScreenHz(Number(e.target.value) as 60 | 90 | 120)}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-xs font-mono font-semibold text-slate-900 dark:text-white"
              >
                <option value={60}>60 Hz</option>
                <option value={90}>90 Hz</option>
                <option value={120}>120 Hz</option>
              </select>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-500 dark:text-slate-400">
                {isAr ? 'تدرّج سرعة اللمس المفضلة' : 'Preferred Touch Speed Scale'}
              </span>
              <span className="font-mono font-semibold text-[#00A3FF] tabular-nums" dir="ltr">
                {baseTouchScale}%
              </span>
            </div>
            <input
              type="range"
              min={75}
              max={130}
              step={5}
              value={baseTouchScale}
              onChange={(e) => setBaseTouchScale(Number(e.target.value))}
              className="w-full accent-[#00A3FF]"
            />
          </div>

          <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs">
            {[
              {
                label: isAr ? 'الكاميرا / بدون منظار' : 'Camera / No Scope',
                val: sensProfile.cameraNoScope,
              },
              {
                label: isAr ? 'منظار النقطة الحمراء (ADS Red Dot)' : 'ADS Red Dot / Holo',
                val: sensProfile.adsRedDot,
              },
              {
                label: isAr ? 'منظار 2x / 3x' : 'ADS 2x / 3x Scope',
                val: sensProfile.ads3x,
              },
              {
                label: isAr ? 'منظار 4x / 6x' : 'ADS 4x / 6x Scope',
                val: sensProfile.ads6x,
              },
              {
                label: isAr ? 'الجيروسكوب (Red Dot)' : 'Gyroscope (Red Dot)',
                val: sensProfile.gyroRedDot,
              },
              {
                label: isAr ? 'الجيروسكوب (4x)' : 'Gyroscope (4x)',
                val: sensProfile.gyro4x,
              },
            ].map((row) => (
              <div key={row.label} className="py-2.5 flex items-center justify-between gap-2">
                <span className="text-slate-600 dark:text-slate-300">{row.label}</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums" dir="ltr">
                  {row.val} / {sensProfile.maxLabel}
                </span>
              </div>
            ))}
          </div>

          <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
            {isAr
              ? 'أدخل هذه القيم يدوياً في إعدادات الحساسية داخل اللعبة وجرّبها في ساحة التدريب لتقليل ارتداد السلاح بيدك.'
              : 'Enter these baseline ratios manually in your in-game Sensitivity settings and fine-tune in Training Grounds for cleaner recoil control.'}
          </p>
        </section>
      </div>
    </div>
  );
};

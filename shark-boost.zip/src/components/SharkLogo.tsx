import React, { useState } from 'react';

interface SharkLogoProps {
  size?: number;
  variant?: 'svg' | 'artwork';
  className?: string;
}

export const SharkLogo: React.FC<SharkLogoProps> = ({
  size = 36,
  variant = 'svg',
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);

  if (variant === 'artwork' && !imgError) {
    return (
      <img
        src="/src/assets/images/shark_boost_logo_1794668573118.jpg"
        alt="SHARK BOOST logo"
        referrerPolicy="no-referrer"
        onError={() => setImgError(true)}
        style={{ width: size, height: size }}
        className={`rounded-2xl object-cover shrink-0 border border-sky-500/30 ${className}`}
      />
    );
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
      aria-hidden="true"
    >
      <rect width="64" height="64" rx="16" className="fill-slate-900 dark:fill-[#0A101B]" />
      <rect
        x="1"
        y="1"
        width="62"
        height="62"
        rx="15"
        stroke="#00A3FF"
        strokeOpacity="0.35"
        strokeWidth="1.5"
      />
      <path
        d="M12 43L22 32L29 14L40 28L53 32L41 39L44 48L32 42L20 50L23 39L12 43Z"
        className="fill-[#0E1A2E]"
        stroke="#00A3FF"
        strokeWidth="2.4"
        strokeLinejoin="round"
      />
      <path
        d="M29 14L35.5 30.5L51 32"
        stroke="#38BDF8"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M36.5 29.5L41 31.8L36 33.2Z" fill="#38BDF8" />
    </svg>
  );
};

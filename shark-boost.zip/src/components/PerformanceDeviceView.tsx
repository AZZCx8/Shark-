import React, { useState } from 'react';
import {
  Cpu,
  MemoryStick,
  HardDrive,
  Battery,
  CheckCircle2,
  Circle,
  ShieldCheck,
  RefreshCw,
  SlidersHorizontal,
  ExternalLink,
} from 'lucide-react';
import type { DeviceTelemetry, Language } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import { openAndroidSetting } from '../services/androidBridge';
import { StutterAnalyzer } from './StutterAnalyzer';

interface PerformanceDeviceViewProps {
  t: TranslationSet;
  lang: Language;
  telemetry: DeviceTelemetry;
  onRefreshTelemetry: () => void;
}

export const PerformanceDeviceView: React.FC<PerformanceDeviceViewProps> = ({
  t,
  lang,
  telemetry,
  onRefreshTelemetry,
}) => {
  const [subTab, setSubTab] = useState<'assistant' | 'optimization'>('assistant');
  const [ramTier, setRamTier] = useState<'low' | 'mid' | 'high'>(() => {
    const gb = telemetry.deviceMemoryGb;
    if (gb !== null && gb <= 3) return 'low';
    if (gb !== null && gb <= 6) return 'mid';
    return 'low';
  });
  const [checkedSteps, setCheckedSteps] = useState<Record<string, boolean>>({});
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const toggleStep = (key: string) => {
    setCheckedSteps((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleChecklistAction = async (
    key: 'batterySaver' | 'backgroundMedia' | 'storageSpace' | 'dndMode' | 'syncPaused'
  ) => {
    setActionNotice(null);
    if (key === 'batterySaver') {
      const res = await openAndroidSetting('battery');
      if (res.mode === 'intent' && res.intentUri) {
        window.location.href = res.intentUri;
      } else if (res.mode === 'info') {
        setActionNotice(t.gaming.webIntentInfo);
      }
      toggleStep(key);
      return;
    }
    if (key === 'dndMode') {
      const res = await openAndroidSetting('dnd');
      if (res.mode === 'intent' && res.intentUri) {
        window.location.href = res.intentUri;
      } else if (res.mode === 'info') {
        setActionNotice(t.gaming.webIntentInfo);
      }
      toggleStep(key);
      return;
    }
    if (key === 'syncPaused') {
      const res = await openAndroidSetting('wifi');
      if (res.mode === 'intent' && res.intentUri) {
        window.location.href = res.intentUri;
      } else if (res.mode === 'info') {
        setActionNotice(t.gaming.webIntentInfo);
      }
      toggleStep(key);
      return;
    }
    if (key === 'storageSpace') {
      onRefreshTelemetry();
      toggleStep(key);
      return;
    }
    toggleStep(key);
  };

  const ramDisplay =
    telemetry.nativeTotalMemMb && telemetry.nativeAvailMemMb
      ? `${telemetry.nativeAvailMemMb} / ${telemetry.nativeTotalMemMb} MB`
      : telemetry.deviceMemoryGb !== null
      ? `~${telemetry.deviceMemoryGb} GB`
      : t.common.unsupported;

  const storageDisplay =
    telemetry.storageQuotaMb !== null && telemetry.storageUsedMb !== null
      ? `${Math.max(0, telemetry.storageQuotaMb - telemetry.storageUsedMb)} MB free`
      : t.common.unsupported;

  const batteryDisplay =
    telemetry.batteryPercent !== null
      ? `${telemetry.batteryPercent}% · ${
          telemetry.batteryCharging ? t.performance.charging : t.performance.discharging
        }${telemetry.batteryTempC ? ` · ${telemetry.batteryTempC}°C` : ''}`
      : t.common.unsupported;

  const checklistKeys = [
    'batterySaver',
    'backgroundMedia',
    'storageSpace',
    'dndMode',
    'syncPaused',
  ] as const;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white text-balance">
            {t.performance.title}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            {t.performance.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 self-start">
          <button
            type="button"
            onClick={() => setSubTab('assistant')}
            className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'assistant'
                ? 'bg-white dark:bg-[#00A3FF] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            {t.performance.tabAssistant}
          </button>
          <button
            type="button"
            onClick={() => setSubTab('optimization')}
            className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              subTab === 'optimization'
                ? 'bg-white dark:bg-[#00A3FF] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300'
            }`}
          >
            {t.performance.tabOptimization}
          </button>
        </div>
      </div>

      {subTab === 'assistant' ? (
        <div className="space-y-6">
          {/* Real Hardware Snapshot */}
          <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.performance.hardwareTitle}
              </h2>
              <button
                type="button"
                onClick={onRefreshTelemetry}
                className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium text-slate-600 dark:text-slate-300 hover:border-[#00A3FF] flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{t.common.refresh}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <Cpu className="w-4 h-4 text-[#00A3FF]" />
                  <span>{t.performance.cpuCores}</span>
                </div>
                <p className="text-lg font-bold font-mono text-slate-900 dark:text-white tabular-nums" dir="ltr">
                  {telemetry.cpuCores !== null ? `${telemetry.cpuCores} cores` : t.common.unsupported}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <MemoryStick className="w-4 h-4 text-[#00A3FF]" />
                  <span>{t.performance.ramLabel}</span>
                </div>
                <p className="text-lg font-bold font-mono text-slate-900 dark:text-white tabular-nums" dir="ltr">
                  {ramDisplay}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <HardDrive className="w-4 h-4 text-[#00A3FF]" />
                  <span>{t.performance.storageLabel}</span>
                </div>
                <p className="text-lg font-bold font-mono text-slate-900 dark:text-white tabular-nums" dir="ltr">
                  {storageDisplay}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1.5">
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <Battery className="w-4 h-4 text-[#00A3FF]" />
                  <span>{t.performance.batteryLabel}</span>
                </div>
                <p className="text-sm font-bold font-mono text-slate-900 dark:text-white tabular-nums pt-0.5" dir="ltr">
                  {batteryDisplay}
                </p>
              </div>
            </div>
          </section>

          {/* Honest Actionable Pre-Game Checklist */}
          <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t.performance.checklistTitle}
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {t.performance.checklistDesc}
              </p>
            </div>

            {actionNotice && (
              <div className="rounded-xl bg-sky-500/10 border border-sky-500/25 px-3.5 py-2.5 text-xs text-slate-700 dark:text-slate-200">
                {actionNotice}
              </div>
            )}

            <div className="divide-y divide-slate-100 dark:divide-white/5">
              {checklistKeys.map((key) => {
                const item = t.performance.items[key];
                const done = !!checkedSteps[key];
                return (
                  <div
                    key={key}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <button
                      type="button"
                      onClick={() => toggleStep(key)}
                      className="flex items-start gap-3 text-start flex-1 min-h-[44px]"
                    >
                      {done ? (
                        <CheckCircle2 className="w-5 h-5 text-[#00A3FF] shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <p
                          className={`text-sm font-semibold ${
                            done
                              ? 'line-through text-slate-400 dark:text-slate-500'
                              : 'text-slate-900 dark:text-white'
                          }`}
                        >
                          {item.title}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                          {item.desc}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleChecklistAction(key)}
                      className="min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-xs font-semibold text-slate-700 dark:text-slate-200 shrink-0 self-start sm:self-center transition-colors whitespace-nowrap"
                    >
                      {done ? t.performance.checklistDone : item.action}
                    </button>
                  </div>
                );
              })}
            </div>
          </section>

          <StutterAnalyzer lang={lang} />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Low-End Device Competitive Profile */}
          <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-5 h-5 text-[#00A3FF]" />
                  <h2 className="text-base font-bold text-slate-900 dark:text-white">
                    {lang === 'ar'
                      ? 'ملف الأجهزة الضعيفة والألعاب التنافسية الخفيفة'
                      : 'Low-End Device & Competitive Games Optimizer'}
                  </h2>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {lang === 'ar'
                    ? 'اختر فئة الذاكرة في هاتفك للحصول على أدق إعدادات تقليل التقطيع في الألعاب التنافسية.'
                    : 'Select your phone RAM tier for practical anti-stutter settings tailored to competitive mobile titles.'}
                </p>
              </div>

              <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 self-start">
                {[
                  { id: 'low' as const, label: '2–3 GB' },
                  { id: 'mid' as const, label: '4–6 GB' },
                  { id: 'high' as const, label: '8+ GB' },
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setRamTier(tier.id)}
                    className={`min-h-[38px] px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-colors ${
                      ramTier === tier.id
                        ? 'bg-[#00A3FF] text-white'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">Free Fire</p>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  {ramTier === 'low'
                    ? lang === 'ar'
                      ? 'الجرافيكس: ناعم (Smooth) · الظلال: إيقاف · High FPS: عادي (لتجنب الحرارة) · حذف حزم الأزياء غير المستخدمة.'
                      : 'Display: Smooth · Shadows: Off · High FPS: Normal to avoid thermal drops · Clear unused skin packs.'
                    : lang === 'ar'
                    ? 'الجرافيكس: قياسي (Standard) · High FPS: مفعّل · إيقاف High Res Textures لثبات الفريمات.'
                    : 'Display: Standard · High FPS: On · Keep High Res Textures off for steady frame times.'}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">Blood Strike</p>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  {ramTier === 'low'
                    ? lang === 'ar'
                      ? 'دقة العرض: Low · معدل الإطارات: High (45-60) · إغلاق Anti-Aliasing والضباب الديناميكي.'
                      : 'Resolution: Low · Frame Rate: High · Disable Anti-Aliasing and dynamic bloom.'
                    : lang === 'ar'
                    ? 'دقة العرض: Medium · معدل الإطارات: Ultra · تفعيل أولوية ثبات الإطارات.'
                    : 'Resolution: Medium · Frame Rate: Ultra · Prioritize frame pacing stability.'}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">PUBG MOBILE</p>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  {ramTier === 'low'
                    ? lang === 'ar'
                      ? 'الرسوميات: سلسة (Smooth) · الإطارات: متوسطة/عالية · الصوت: منخفض (Low) · إغلاق الظلال والتعديل التلقائي.'
                      : 'Graphics: Smooth · Frame Rate: Medium/High · Audio: Low · Turn off Shadows and Auto-Adjust.'
                    : lang === 'ar'
                    ? 'الرسوميات: سلسة (Smooth) · الإطارات: فائقة (Extreme) · إغلاق الظلال ومضاد التعرج.'
                    : 'Graphics: Smooth · Frame Rate: Extreme · Disable Shadows and Anti-Aliasing.'}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">Standoff 2</p>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  {ramTier === 'low'
                    ? lang === 'ar'
                      ? 'Shader Detail: Very Low · Texture Detail: Low · إيقاف Anti-Aliasing · قفل 60fps.'
                      : 'Shader Detail: Very Low · Texture Detail: Low · Disable Anti-Aliasing · Cap at 60fps.'
                    : lang === 'ar'
                    ? 'Shader Detail: Low · Texture: Medium · تفعيل 90/120fps إذا كانت الشاشة تدعمه.'
                    : 'Shader Detail: Low · Texture: Medium · Match 90/120fps to your panel refresh rate.'}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">Brawl Stars & MOBA</p>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                  {lang === 'ar'
                    ? 'خيارات المطور: تقليل مقياس حركة النوافذ إلى 0.5x + استثناء اللعبة من تحسين البطارية لمنع إغلاقها بالخلفية.'
                    : 'Set Window Animation Scale to 0.5x in Developer Options and mark the game as Battery Unrestricted.'}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 flex flex-col justify-between gap-2">
                <p className="font-bold text-slate-900 dark:text-white">
                  {lang === 'ar' ? 'اختصارات أندرويد للأجهزة الضعيفة' : 'Android Weak-Device Shortcuts'}
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await openAndroidSetting('developer');
                      if (res.mode === 'intent' && res.intentUri) {
                        window.location.href = res.intentUri;
                      } else if (res.mode === 'info') {
                        setActionNotice(t.gaming.webIntentInfo);
                      }
                    }}
                    className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'خيارات المطور' : 'Developer Options'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await openAndroidSetting('battery_optimization');
                      if (res.mode === 'intent' && res.intentUri) {
                        window.location.href = res.intentUri;
                      } else if (res.mode === 'info') {
                        setActionNotice(t.gaming.webIntentInfo);
                      }
                    }}
                    className="min-h-[38px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'تحسين البطارية' : 'Battery Optimization'}</span>
                  </button>
                </div>
              </div>
            </div>

            {actionNotice && (
              <div className="rounded-xl bg-sky-500/10 border border-sky-500/25 px-3.5 py-2.5 text-xs text-slate-700 dark:text-slate-200">
                {actionNotice}
              </div>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {t.performance.guides.map((guide, index) => (
              <article
                key={guide.title}
                className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-2"
              >
                <p className="text-xs font-mono text-[#00A3FF]">0{index + 1}.</p>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  {guide.title}
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {guide.body}
                </p>
              </article>
            ))}
          </div>

          <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 flex items-start gap-3.5">
            <ShieldCheck className="w-6 h-6 text-[#00A3FF] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {t.performance.privacyBoxTitle}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {t.performance.privacyBoxBody}
              </p>
            </div>
          </section>
        </div>
      )}
    </div>
  );
};

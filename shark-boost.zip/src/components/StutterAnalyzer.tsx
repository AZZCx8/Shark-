import React, { useState } from 'react';
import { Activity, Play } from 'lucide-react';
import type { Language } from '../types/shark';

interface StutterAnalyzerProps {
  lang: Language;
}

interface StutterResult {
  samples: number[];
  avgMs: number;
  maxSpikeMs: number;
  stutterEvents: number;
  estimatedHz: number;
}

export const StutterAnalyzer: React.FC<StutterAnalyzerProps> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<StutterResult | null>(null);

  const runStutterCheck = () => {
    if (running) return;
    setRunning(true);
    const frameTimes: number[] = [];
    let last: number | null = null;
    let count = 0;
    const totalFrames = 180;

    function tick(now: number) {
      if (last !== null) {
        const dt = now - last;
        if (dt > 0 && dt < 250) {
          frameTimes.push(Math.round(dt * 10) / 10);
        }
      }
      last = now;
      count += 1;

      if (count <= totalFrames) {
        requestAnimationFrame(tick);
      } else {
        const avg =
          frameTimes.length > 0
            ? frameTimes.reduce((a, b) => a + b, 0) / frameTimes.length
            : 16.7;
        const maxSpike = frameTimes.length > 0 ? Math.max(...frameTimes) : 16.7;
        const threshold = avg * 1.55;
        const stutters = frameTimes.filter((t) => t > threshold).length;
        setResult({
          samples: frameTimes.slice(-60),
          avgMs: Math.round(avg * 10) / 10,
          maxSpikeMs: Math.round(maxSpike * 10) / 10,
          stutterEvents: stutters,
          estimatedHz: Math.round(1000 / avg),
        });
        setRunning(false);
      }
    }

    requestAnimationFrame(tick);
  };

  return (
    <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#00A3FF]" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {isAr ? 'مقياس التقطيع وثبات الإطارات (180 إطار)' : 'Frame-Time Stutter Analyzer (180 Frames)'}
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'يرصد الارتفاعات المفاجئة في زمن الإطار (Frame Spikes) التي تسبب التقطيع أثناء اللعب.'
              : 'Detects real frame-time spikes that cause visual stutter during competitive gameplay.'}
          </p>
        </div>

        <button
          type="button"
          disabled={running}
          onClick={runStutterCheck}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-xs font-semibold flex items-center justify-center gap-2 shrink-0 disabled:opacity-60 transition-colors"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          <span>
            {running
              ? isAr
                ? 'جاري فحص الثبات...'
                : 'Analyzing...'
              : isAr
              ? 'فحص التقطيع الآن'
              : 'Run Stutter Check'}
          </span>
        </button>
      </div>

      {result && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'متوسط الإطار' : 'Avg Frame'}
              </span>
              <span className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {result.avgMs} ms
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'أعلى قفزة تقطيع' : 'Max Spike'}
              </span>
              <span className="font-mono text-base font-bold text-amber-500 tabular-nums" dir="ltr">
                {result.maxSpikeMs} ms
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'مرات التقطيع' : 'Stutter Spikes'}
              </span>
              <span className="font-mono text-base font-bold text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {result.stutterEvents} / 180
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                {isAr ? 'تردد العرض المقاس' : 'Measured Hz'}
              </span>
              <span className="font-mono text-base font-bold text-[#00A3FF] tabular-nums" dir="ltr">
                {result.estimatedHz} Hz
              </span>
            </div>
          </div>

          <div className="h-24 flex items-end gap-0.5 p-2 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5">
            {result.samples.map((ms, idx) => {
              const heightPct = Math.min(100, Math.max(12, (ms / Math.max(35, result.maxSpikeMs)) * 100));
              const isSpike = ms > result.avgMs * 1.55;
              return (
                <div
                  key={`${idx}-${ms}`}
                  style={{ height: `${heightPct}%` }}
                  title={`${ms} ms`}
                  className={`flex-1 rounded-t-sm ${
                    isSpike ? 'bg-amber-500' : 'bg-[#00A3FF]/80'
                  }`}
                />
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
};

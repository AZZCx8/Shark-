import React, { useMemo, useRef, useState } from 'react';
import { Play, Square, Wifi, AlertTriangle, Globe, Copy, Check, ExternalLink } from 'lucide-react';
import type { DeviceTelemetry, Language, NetworkSample, NetworkStats } from '../types/shark';
import type { TranslationSet } from '../i18n/translations';
import { openAndroidSetting } from '../services/androidBridge';

interface NetworkToolsViewProps {
  t: TranslationSet;
  lang: Language;
  telemetry: DeviceTelemetry;
}

type TargetPreset = 'local' | 'cloudflare' | 'google' | 'custom';

interface RouteBenchmarkResult {
  id: 'cloudflare' | 'google' | 'local';
  label: string;
  dnsHostname?: string;
  avgMs: number | null;
  lossPct: number;
}

export const NetworkToolsView: React.FC<NetworkToolsViewProps> = ({ t, lang, telemetry }) => {
  const isAr = lang === 'ar';
  const [target, setTarget] = useState<TargetPreset>('local');
  const [customUrl, setCustomUrl] = useState('https://1.1.1.1');
  const [sampleCount, setSampleCount] = useState(15);
  const [intervalMs, setIntervalMs] = useState(350);
  const [running, setRunning] = useState(false);
  const [samples, setSamples] = useState<NetworkSample[]>([]);
  const [comparing, setComparing] = useState(false);
  const [routeResults, setRouteResults] = useState<RouteBenchmarkResult[]>([]);
  const [copiedHost, setCopiedHost] = useState<string | null>(null);
  const abortRef = useRef(false);

  const runRouteComparison = async () => {
    if (comparing || running) return;
    setComparing(true);
    const endpoints: Array<{
      id: 'cloudflare' | 'google' | 'local';
      label: string;
      url: string;
      mode: RequestMode;
      dnsHostname?: string;
      headers?: HeadersInit;
    }> = [
      {
        id: 'cloudflare',
        label: 'Cloudflare DNS (1.1.1.1)',
        url: 'https://cloudflare-dns.com/dns-query?name=example.com&type=A',
        mode: 'cors',
        dnsHostname: 'one.one.one.one',
        headers: { Accept: 'application/dns-json' },
      },
      {
        id: 'google',
        label: 'Google DNS (8.8.8.8)',
        url: 'https://dns.google/resolve?name=example.com&type=A',
        mode: 'cors',
        dnsHostname: 'dns.google',
      },
      {
        id: 'local',
        label: t.network.targets.local,
        url: '/api/probe',
        mode: 'same-origin',
      },
    ];

    const out: RouteBenchmarkResult[] = [];
    for (const ep of endpoints) {
      const rtts: number[] = [];
      let fails = 0;
      for (let i = 0; i < 4; i++) {
        const ctrl = new AbortController();
        const tid = window.setTimeout(() => ctrl.abort(), 2200);
        const start = performance.now();
        try {
          await fetch(`${ep.url}${ep.url.includes('?') ? '&' : '?'}_c=${Date.now()}_${i}`, {
            mode: ep.mode,
            cache: 'no-store',
            headers: ep.headers,
            signal: ctrl.signal,
          });
          window.clearTimeout(tid);
          rtts.push(performance.now() - start);
        } catch {
          window.clearTimeout(tid);
          fails += 1;
        }
      }
      out.push({
        id: ep.id,
        label: ep.label,
        dnsHostname: ep.dnsHostname,
        avgMs: rtts.length ? Math.round((rtts.reduce((a, b) => a + b, 0) / rtts.length) * 10) / 10 : null,
        lossPct: Math.round((fails / 4) * 100),
      });
    }
    setRouteResults(out);
    setComparing(false);
  };

  const copyDnsHost = async (host: string) => {
    try {
      await navigator.clipboard.writeText(host);
      setCopiedHost(host);
      window.setTimeout(() => setCopiedHost(null), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  };

  const openNetworkSettings = async () => {
    const res = await openAndroidSetting('network');
    if (res.mode === 'intent' && res.intentUri) {
      window.location.href = res.intentUri;
    }
  };

  const resolveEndpoint = (): { url: string; mode: RequestMode } => {
    if (target === 'local') {
      return { url: '/api/probe', mode: 'same-origin' };
    }
    if (target === 'cloudflare') {
      return { url: 'https://cloudflare-dns.com/dns-query?name=example.com&type=A', mode: 'cors' };
    }
    if (target === 'google') {
      return { url: 'https://dns.google/resolve?name=example.com&type=A', mode: 'cors' };
    }
    const sanitized = customUrl.trim().startsWith('http')
      ? customUrl.trim()
      : `https://${customUrl.trim()}`;
    return { url: sanitized, mode: 'no-cors' };
  };

  const stats: NetworkStats = useMemo(() => {
    const sent = samples.length;
    const okSamples = samples.filter((s) => s.status === 'ok' && s.rttMs !== null);
    const received = okSamples.length;
    const lost = sent - received;
    const lossPercent = sent > 0 ? Math.round((lost / sent) * 1000) / 10 : 0;
    const rtts = okSamples.map((s) => s.rttMs as number);
    const jitters = okSamples
      .map((s) => s.jitterMs)
      .filter((j): j is number => j !== null);

    return {
      sent,
      received,
      lost,
      lossPercent,
      minMs: rtts.length ? Math.min(...rtts) : null,
      avgMs: rtts.length ? Math.round((rtts.reduce((a, b) => a + b, 0) / rtts.length) * 10) / 10 : null,
      maxMs: rtts.length ? Math.max(...rtts) : null,
      jitterMs: jitters.length
        ? Math.round((jitters.reduce((a, b) => a + b, 0) / jitters.length) * 10) / 10
        : null,
    };
  }, [samples]);

  const qualityLabel = useMemo(() => {
    if (stats.avgMs === null) return null;
    if (stats.lossPercent >= 5 || stats.avgMs > 120 || (stats.jitterMs ?? 0) > 35) {
      return { text: t.network.quality.poor, tone: 'text-rose-500' };
    }
    if (stats.avgMs > 70 || (stats.jitterMs ?? 0) > 18) {
      return { text: t.network.quality.fair, tone: 'text-amber-500' };
    }
    if (stats.avgMs <= 40 && (stats.jitterMs ?? 0) <= 10 && stats.lossPercent === 0) {
      return { text: t.network.quality.excellent, tone: 'text-[#00A3FF]' };
    }
    return { text: t.network.quality.good, tone: 'text-emerald-500' };
  }, [stats, t]);

  const startProbe = async () => {
    if (running) return;
    abortRef.current = false;
    setRunning(true);
    setSamples([]);

    const { url, mode } = resolveEndpoint();
    let prevRtt: number | null = null;

    for (let i = 1; i <= sampleCount; i++) {
      if (abortRef.current) break;
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 2500);
      const separator = url.includes('?') ? '&' : '?';
      const probeUrl = `${url}${separator}_sb=${Date.now()}_${i}`;
      const start = performance.now();

      try {
        const headers: HeadersInit =
          target === 'cloudflare' ? { Accept: 'application/dns-json' } : {};
        await fetch(probeUrl, {
          method: 'GET',
          mode,
          cache: 'no-store',
          headers,
          signal: controller.signal,
        });
        window.clearTimeout(timeoutId);
        const rtt = Math.round((performance.now() - start) * 10) / 10;
        const jitter = prevRtt !== null ? Math.round(Math.abs(rtt - prevRtt) * 10) / 10 : null;
        prevRtt = rtt;

        setSamples((prev) => [
          ...prev,
          { seq: i, rttMs: rtt, jitterMs: jitter, status: 'ok', timestamp: Date.now() },
        ]);
      } catch (err) {
        window.clearTimeout(timeoutId);
        const isAbort = err instanceof DOMException && err.name === 'AbortError';
        setSamples((prev) => [
          ...prev,
          {
            seq: i,
            rttMs: null,
            jitterMs: null,
            status: isAbort ? 'timeout' : 'error',
            timestamp: Date.now(),
          },
        ]);
      }

      if (i < sampleCount && !abortRef.current) {
        await new Promise((r) => setTimeout(r, intervalMs));
      }
    }

    setRunning(false);
  };

  const stopProbe = () => {
    abortRef.current = true;
    setRunning(false);
  };

  const chartPoints = useMemo(() => {
    const valid = samples.filter((s) => s.rttMs !== null);
    if (valid.length < 2) return { rttPath: '', jitterPath: '', maxVal: 100 };
    const maxRtt = Math.max(50, ...valid.map((s) => s.rttMs ?? 0));
    const width = 560;
    const height = 140;
    const padX = 12;
    const padY = 14;
    const stepX = (width - padX * 2) / Math.max(1, samples.length - 1);

    const rttCoords: string[] = [];
    const jitterCoords: string[] = [];

    samples.forEach((s, idx) => {
      const x = padX + idx * stepX;
      if (s.rttMs !== null) {
        const y = height - padY - (s.rttMs / maxRtt) * (height - padY * 2);
        rttCoords.push(`${rttCoords.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
      }
      if (s.jitterMs !== null) {
        const jy = height - padY - (Math.min(s.jitterMs, maxRtt) / maxRtt) * (height - padY * 2);
        jitterCoords.push(`${jitterCoords.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${jy.toFixed(1)}`);
      }
    });

    return {
      rttPath: rttCoords.join(' '),
      jitterPath: jitterCoords.join(' '),
      maxVal: Math.ceil(maxRtt),
    };
  }, [samples]);

  return (
    <div className="space-y-6">
      <div className="space-y-1.5">
        <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white text-balance">
          {t.network.title}
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
          {t.network.subtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Controls Panel */}
        <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-200 mb-1.5">
              {t.network.targetLabel}
            </label>
            <select
              value={target}
              disabled={running}
              onChange={(e) => setTarget(e.target.value as TargetPreset)}
              className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
            >
              <option value="local">{t.network.targets.local}</option>
              <option value="cloudflare">{t.network.targets.cloudflare}</option>
              <option value="google">{t.network.targets.google}</option>
              <option value="custom">{t.network.targets.custom}</option>
            </select>
          </div>

          {target === 'custom' && (
            <div>
              <input
                type="url"
                dir="ltr"
                disabled={running}
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder={t.network.customUrlPlaceholder}
                className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#00A3FF]"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                {t.network.samplesLabel}
              </label>
              <select
                value={sampleCount}
                disabled={running}
                onChange={(e) => setSampleCount(Number(e.target.value))}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-mono"
              >
                <option value={10}>10</option>
                <option value={15}>15</option>
                <option value={25}>25</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
                {t.network.intervalLabel}
              </label>
              <select
                value={intervalMs}
                disabled={running}
                onChange={(e) => setIntervalMs(Number(e.target.value))}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/10 text-slate-900 dark:text-white text-sm font-mono"
              >
                <option value={250}>250 ms</option>
                <option value={350}>350 ms</option>
                <option value={600}>600 ms</option>
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={running ? stopProbe : startProbe}
            className={`w-full min-h-[48px] px-4 py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
              running
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-[#00A3FF] hover:bg-[#0284C7] text-white'
            }`}
          >
            {running ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{running ? t.network.stopTest : t.network.startTest}</span>
          </button>

          <p className="text-xs leading-relaxed text-slate-500 dark:text-slate-400">
            {t.network.honestNote}
          </p>

          {/* Device Network Information API */}
          <div className="pt-4 border-t border-slate-200 dark:border-white/10 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200">
              <Wifi className="w-4 h-4 text-[#00A3FF]" />
              <span>{t.network.connectionInfoTitle}</span>
            </div>
            <div className="grid grid-cols-2 gap-y-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400">{t.network.connType}</span>
              <span className="font-mono text-end text-slate-900 dark:text-white" dir="ltr">
                {telemetry.connectionType ?? '—'}
              </span>
              <span className="text-slate-500 dark:text-slate-400">{t.network.downlink}</span>
              <span className="font-mono text-end text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {telemetry.connectionDownlinkMbps !== null
                  ? `${telemetry.connectionDownlinkMbps} Mbps`
                  : '—'}
              </span>
              <span className="text-slate-500 dark:text-slate-400">{t.network.browserRtt}</span>
              <span className="font-mono text-end text-slate-900 dark:text-white tabular-nums" dir="ltr">
                {telemetry.connectionRttMs !== null ? `${telemetry.connectionRttMs} ms` : '—'}
              </span>
            </div>
          </div>
        </section>

        {/* Live Telemetry & Chart */}
        <section className="lg:col-span-2 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">{t.network.avgLatency}</p>
              <p className="text-2xl font-bold font-mono text-slate-900 dark:text-white tabular-nums mt-1" dir="ltr">
                {stats.avgMs !== null ? `${stats.avgMs} ms` : '—'}
              </p>
            </div>
            <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">{t.network.jitter}</p>
              <p className="text-2xl font-bold font-mono text-slate-900 dark:text-white tabular-nums mt-1" dir="ltr">
                {stats.jitterMs !== null ? `${stats.jitterMs} ms` : '—'}
              </p>
            </div>
            <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">{t.network.packetLoss}</p>
              <p className="text-2xl font-bold font-mono text-slate-900 dark:text-white tabular-nums mt-1" dir="ltr">
                {samples.length > 0 ? `${stats.lossPercent}%` : '—'}
              </p>
            </div>
            <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-4">
              <p className="text-xs text-slate-500 dark:text-slate-400">{t.network.minMax}</p>
              <p className="text-lg font-bold font-mono text-slate-900 dark:text-white tabular-nums mt-1.5" dir="ltr">
                {stats.minMs !== null && stats.maxMs !== null
                  ? `${stats.minMs} / ${stats.maxMs}`
                  : '—'}
              </p>
            </div>
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                {t.network.chartTitle}
              </h2>
              {qualityLabel && (
                <span className={`text-xs font-semibold ${qualityLabel.tone}`}>
                  {qualityLabel.text}
                </span>
              )}
            </div>

            {samples.length === 0 ? (
              <div className="h-36 flex items-center justify-center text-sm text-slate-500 dark:text-slate-400 text-center px-4">
                {t.network.noDataYet}
              </div>
            ) : (
              <div className="w-full overflow-hidden">
                <svg
                  viewBox="0 0 560 140"
                  className="w-full h-36 bg-slate-50 dark:bg-[#070B12] rounded-xl border border-slate-200 dark:border-white/5"
                >
                  <line x1="0" y1="35" x2="560" y2="35" stroke="currentColor" className="text-slate-200 dark:text-white/5" strokeDasharray="4 4" />
                  <line x1="0" y1="70" x2="560" y2="70" stroke="currentColor" className="text-slate-200 dark:text-white/5" strokeDasharray="4 4" />
                  <line x1="0" y1="105" x2="560" y2="105" stroke="currentColor" className="text-slate-200 dark:text-white/5" strokeDasharray="4 4" />
                  {chartPoints.jitterPath && (
                    <path
                      d={chartPoints.jitterPath}
                      fill="none"
                      stroke="#F59E0B"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeOpacity="0.8"
                    />
                  )}
                  {chartPoints.rttPath && (
                    <path
                      d={chartPoints.rttPath}
                      fill="none"
                      stroke="#00A3FF"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  )}
                </svg>
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mt-2 font-mono" dir="ltr">
                  <span>0 ms</span>
                  <span>
                    RTT (blue) · Jitter (amber) · {stats.received}/{stats.sent} pkts
                  </span>
                  <span>{chartPoints.maxVal} ms</span>
                </div>
              </div>
            )}
          </div>

          {samples.length > 0 && (
            <div className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white mb-3">
                {t.network.logTitle}
              </h3>
              <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 dark:divide-white/5">
                {[...samples].reverse().map((sample) => (
                  <div
                    key={sample.seq}
                    className="flex items-center justify-between py-2 text-xs font-mono tabular-nums"
                    dir="ltr"
                  >
                    <span className="text-slate-500 dark:text-slate-400">#{sample.seq}</span>
                    {sample.status === 'ok' ? (
                      <span className="text-slate-900 dark:text-white">
                        RTT {sample.rttMs} ms
                        {sample.jitterMs !== null ? ` · Jitter ${sample.jitterMs} ms` : ''}
                      </span>
                    ) : (
                      <span className="text-rose-500 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{sample.status.toUpperCase()}</span>
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </div>

      {/* DNS & Route Latency Comparator for Ping Optimization */}
      <section className="rounded-2xl bg-white dark:bg-[#0D131F] border border-slate-200 dark:border-white/10 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-[#00A3FF]" />
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {isAr
                  ? 'مقارنة مسارات الـ DNS لاختيار أقل بنق حقيقي'
                  : 'Real DNS & Route Ping Comparator'}
              </h2>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              {isAr
                ? 'يفحص أسرع مزود DNS لاتصالك الحالي لتعيينه في إعدادات Private DNS على أندرويد.'
                : 'Benchmarks live DNS endpoints on your connection so you can configure the lowest-latency Private DNS on Android.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={comparing || running}
              onClick={runRouteComparison}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#00A3FF] hover:bg-[#0284C7] text-white text-xs font-semibold transition-colors disabled:opacity-60 whitespace-nowrap"
            >
              {comparing
                ? isAr
                  ? 'جاري المقارنة...'
                  : 'Benchmarking...'
                : isAr
                ? 'فحص أسرع مسار'
                : 'Compare Routes'}
            </button>
            <button
              type="button"
              onClick={openNetworkSettings}
              className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5 whitespace-nowrap"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>{isAr ? 'إعدادات الشبكة' : 'Network Settings'}</span>
            </button>
          </div>
        </div>

        {routeResults.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {routeResults.map((res) => (
              <div
                key={res.id}
                className="p-4 rounded-xl bg-slate-50 dark:bg-[#070B12] border border-slate-200 dark:border-white/5 flex flex-col justify-between gap-3"
              >
                <div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-200" dir="ltr">
                    {res.label}
                  </p>
                  <p className="text-xl font-bold font-mono text-[#00A3FF] tabular-nums mt-1" dir="ltr">
                    {res.avgMs !== null ? `${res.avgMs} ms` : 'Timeout'}
                  </p>
                  <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 mt-0.5" dir="ltr">
                    Loss: {res.lossPct}%
                  </p>
                </div>

                {res.dnsHostname && (
                  <button
                    type="button"
                    onClick={() => copyDnsHost(res.dnsHostname!)}
                    className="min-h-[40px] px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/10 hover:border-[#00A3FF] text-xs font-mono text-slate-700 dark:text-slate-200 flex items-center justify-between gap-2"
                    dir="ltr"
                  >
                    <span>{res.dnsHostname}</span>
                    {copiedHost === res.dnsHostname ? (
                      <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    )}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};

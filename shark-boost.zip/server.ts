import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

function addDirectoryToZip(zip: JSZip, dirPath: string, zipFolder: string) {
  if (!fs.existsSync(dirPath)) return;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    const relZipPath = path.posix.join(zipFolder, entry.name);
    if (entry.isDirectory()) {
      addDirectoryToZip(zip, fullPath, relZipPath);
    } else if (entry.isFile()) {
      zip.file(relZipPath, fs.readFileSync(fullPath));
    }
  }
}

async function startServer() {
  const app = express();

  app.get('/api/probe', (_req, res) => {
    res.set({
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      Pragma: 'no-cache',
      Expires: '0',
    });
    res.json({
      ok: true,
      serverTimestamp: Date.now(),
    });
  });

  app.get('/api/export-android', async (_req, res) => {
    try {
      const zip = new JSZip();
      addDirectoryToZip(zip, path.join(__dirname, 'android'), 'android');

      const capConfig = path.join(__dirname, 'capacitor.config.json');
      if (fs.existsSync(capConfig)) {
        zip.file('capacitor.config.json', fs.readFileSync(capConfig));
      }

      const guide = path.join(__dirname, 'BUILD_APK_GUIDE.md');
      if (fs.existsSync(guide)) {
        zip.file('BUILD_APK_GUIDE.md', fs.readFileSync(guide));
      }

      const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
      res.set({
        'Content-Type': 'application/zip',
        'Content-Disposition': 'attachment; filename="shark-boost-android-project.zip"',
        'Content-Length': String(buffer.length),
      });
      res.send(buffer);
    } catch (error) {
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Failed to export Android project',
      });
    }
  });

  const distDir = path.join(__dirname, 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SHARK BOOST server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

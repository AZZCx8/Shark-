# SHARK BOOST — Android APK Build & Testing Guide

This project is pre-configured with Capacitor (`com.sharkboost.gaming`) and a native Kotlin plugin (`SharkBoostPlugin.kt`) that integrates with legitimate Android APIs without root access, fake RAM cleaners, or background-killer hacks.

## Prerequisites
- Node.js 20+
- JDK 17
- Android Studio (with Android SDK 35 & Build-Tools installed)

## Step-by-Step APK Build
1. Install dependencies and build the production web bundle:
   ```bash
   npm install
   npm run build
   ```
2. Add Capacitor Android platform support (if not already synced in `node_modules`):
   ```bash
   npm install @capacitor/cli @capacitor/android
   npx cap sync android
   ```
3. Build a debug APK for testing on a real Android phone:
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
   The debug APK will be generated at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Install directly onto a connected Android phone (USB Debugging enabled):
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
5. For a signed Play Store / Release APK:
   Open the `android/` folder in Android Studio -> **Build > Generate Signed Bundle / APK**.

## Privacy & Security Architecture
- Uses `PackageManager` with `<queries>` for `CATEGORY_LAUNCHER` apps only.
- Uses `NotificationManager` policy access (`ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS`) only when explicitly requested by the user for Do Not Disturb Gaming Mode.
- Reads hardware state via `ActivityManager.MemoryInfo`, `PowerManager`, and `BatteryManager` without invasive permissions.
